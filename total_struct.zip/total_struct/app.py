from flask import Flask, render_template, jsonify, request, Response
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import io
import csv
import logging
from sqlalchemy import func, and_
import json 

app = Flask(__name__)

# 로깅 설정: INFO 레벨 메시지를 출력하도록 설정
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# MySQL 서버 연결 설정 관련 코드
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://ksi:1234@localhost:3306/mindone?charset=utf8'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JSON_AS_ASCII'] = False

db = SQLAlchemy(app)


class ProDData(db.Model):
    __tablename__ = 'pro_d'

    시각 = db.Column(db.DateTime, primary_key=True, nullable=False)
    유입유량2 = db.Column(db.Float)
    유출유량2 = db.Column(db.Float)
    유출유량2_예측 = db.Column(db.Float)
    유입개도7_추천 = db.Column(db.Float)
    유입개도8_추천 = db.Column(db.Float)
    유입유량1 = db.Column(db.Float)
    유출유량1 = db.Column(db.Float)
    유출유량1_예측 = db.Column(db.Float)
    유입개도1_추천 = db.Column(db.Float)
    유입개도2_추천 = db.Column(db.Float)
    
    수위1 = db.Column(db.Float) 
    수위2 = db.Column(db.Float)
    수위7 = db.Column(db.Float)
    수위8 = db.Column(db.Float)

    수위1_정보 = db.Column(db.String(255))
    수위2_정보 = db.Column(db.String(255))
    수위7_정보 = db.Column(db.String(255))
    수위8_정보 = db.Column(db.String(255))

    수위1_예측 = db.Column(db.Float) 
    수위2_예측 = db.Column(db.Float)
    수위7_예측 = db.Column(db.Float)
    수위8_예측 = db.Column(db.Float)

    수위1_현재위험도 = db.Column(db.String(255))
    수위2_현재위험도 = db.Column(db.String(255))
    수위7_현재위험도 = db.Column(db.String(255))
    수위8_현재위험도 = db.Column(db.String(255))

    수위1_예측위험도 = db.Column(db.String(255))
    수위2_예측위험도 = db.Column(db.String(255))
    수위7_예측위험도 = db.Column(db.String(255))
    수위8_예측위험도 = db.Column(db.String(255))

    유입개도1_회복모드여부 = db.Column(db.String(255))
    유입개도2_회복모드여부 = db.Column(db.String(255))
    유입개도7_회복모드여부 = db.Column(db.String(255))
    유입개도8_회복모드여부 = db.Column(db.String(255))
    
    체적 = db.Column(db.Float)

    def __repr__(self):
        return f'<ProDData 시각={self.시각}>'


with app.app_context():
    try:
        db.create_all() 
        db_info_parts = app.config['SQLALCHEMY_DATABASE_URI'].split('/')
        db_name = db_info_parts[-1].split('?')[0] if '/' in app.config['SQLALCHEMY_DATABASE_URI'] else "N/A"
        logging.info(f"Database '{db_name}' connection and table model verification complete.")
    except Exception as e:
        logging.error(f"Error connecting to database or creating table: {e}")
        logging.error("Please check database connection string, MySQL server status, user permissions, and database/table existence.")


@app.route('/')
def index():
    return render_template('main.html')


@app.route('/info')
def info():
    return render_template('info.html')


@app.route('/deepinfoD')
def deepinfoD():
    return render_template('deepinfoD.html')


@app.route('/get_latest_pro_d_chart_data')
# 데이터를 불러오는 함수
def get_latest_pro_d_chart_data():
    try:
        last_time_str = request.args.get('last_time')
        last_time_from_client = None
        if last_time_str and last_time_str != 'null':
            try:
                last_time_from_client = datetime.fromisoformat(last_time_str.replace('Z', '+00:00'))
                logging.info(f"클라이언트에서 받은 last_time 파싱 성공: {last_time_from_client}")
            except ValueError as ve:
                logging.warning(f"last_time 파싱 오류: {last_time_str} - {ve}. 초기 데이터 요청으로 간주합니다.")
                last_time_from_client = None 

        if not last_time_from_client:
            logging.info("초기 요청 또는 last_time 파싱 오류: DB에서 가장 오래된 시각부터 1개 레코드를 가져옵니다.")
            latest_data_query = db.session.query(ProDData) \
                                        .order_by(ProDData.시각.asc()) \
                                        .limit(1) \
                                        .all()
            logging.info(f"차트 표시를 위해 {len(latest_data_query)}개의 초기 ProDData 레코드를 가져왔습니다 (가장 빠른 시간부터).")
            return _process_pro_d_chart_data(latest_data_query)
        else:
            logging.info(f"시각={last_time_from_client} 이후의 ProDData 차트 데이터를 가져옵니다.")
            latest_data_query = db.session.query(ProDData) \
                                        .filter(ProDData.시각 > last_time_from_client) \
                                        .order_by(ProDData.시각.asc()) \
                                        .limit(1) \
                                        .all()

            if not latest_data_query:
                logging.info(f"현재 {last_time_from_client} 이후에 새로운 ProDData 레코드가 없습니다. 빈 응답을 보냅니다.")
            else:
                logging.info(f"{len(latest_data_query)}개의 새로운 ProDData 레코드를 업데이트용으로 가져왔습니다. 시각: {latest_data_query[0].시각}")
            
            return _process_pro_d_chart_data(latest_data_query)

    except Exception as e:
        logging.error(f"ProDData 차트 데이터를 가져오는 중 오류 발생: {e}", exc_info=True)
        return jsonify({
            "error": str(e),
            "labels": [],
            "시각s": [],
            "유입유량2": [], "유출유량2": [], "유출유량2_예측": [], "유입개도7_추천": [], "유입개도8_추천": [],
            "유입유량1": [], "유출유량1": [], "유출유량1_예측": [], "유입개도1_추천": [], "유입개도2_추천": [],
            "수위1": [], "수위2": [], "수위7": [], "수위8": [], 
            "수위1_정보": [], "수위2_정보": [], "수위7_정보": [], "수위8_정보": [],
            "수위1_예측": [], "수위2_예측": [], "수위7_예측": [], "수위8_예측": [],
            "수위1_현재위험도": [], "수위2_현재위험도": [], "수위7_현재위험도": [], "수위8_현재위험도": [],
            "수위1_예측위험도": [], "수위2_예측위험도": [], "수위7_예측위험도": [], "수위8_예측위험도": [],
            "유입개도1_회복모드여부": [], "유입개도2_회복모드여부": [], "유입개도7_회복모드여부": [], "유입개도8_회복모드여부": [],
            "체적": []
        }), 500


# 차트 데이터 처리를 위한 함수
def _process_pro_d_chart_data(data_rows):
    if not data_rows:
        return jsonify({
            "labels": [],
            "시각s": [],
            "유입유량2": [], "유출유량2": [], "유출유량2_예측": [], "유입개도7_추천": [], "유입개도8_추천": [],
            "유입유량1": [], "유출유량1": [], "유출유량1_예측": [], "유입개도1_추천": [], "유입개도2_추천": [],
            "수위1": [], "수위2": [], "수위7": [], "수위8": [], 
            "수위1_정보": [], "수위2_정보": [], "수위7_정보": [], "수위8_정보": [],
            "수위1_예측": [], "수위2_예측": [], "수위7_예측": [], "수위8_예측": [],
            "수위1_현재위험도": [], "수위2_현재위험도": [], "수위7_현재위험도": [], "수위8_현재위험도": [],
            "수위1_예측위험도": [], "수위2_예측위험도": [], "수위7_예측위험도": [], "수위8_예측위험도": [],
            "유입개도1_회복모드여부": [], "유입개도2_회복모드여부": [], "유입개도7_회복모드여부": [], "유입개도8_회복모드여부": [],
            "체적": [] 
        })

    labels = []
    시각s = []
    data_inflow2 = []
    data_outflow2 = []
    data_pred_outflow2 = []
    data_gate7_rec = []
    data_gate8_rec = []
    data_inflow1 = []
    data_outflow1 = []
    data_pred_outflow1 = []
    data_gate1_rec = []
    data_gate2_rec = []
    
    data_level1_actual = [] 
    data_level2_actual = []
    data_level7_actual = []
    data_level8_actual = []

    data_level1_info = [] 
    data_level2_info = []
    data_level7_info = []
    data_level8_info = []

    data_level1_pred = [] 
    data_level2_pred = []
    data_level7_pred = []
    data_level8_pred = []

    data_current_risk1 = []
    data_current_risk2 = []
    data_current_risk7 = []
    data_current_risk8 = []
    data_pred_risk1 = []
    data_pred_risk2 = []
    data_pred_risk7 = []
    data_pred_risk8 = []
    data_recovery_mode1 = []
    data_recovery_mode2 = []
    data_recovery_mode7 = []
    data_recovery_mode8 = []
    data_volume = []

    for data_row in data_rows:
        # milliseconds 또한 반영
        labels.append(data_row.시각.isoformat(timespec='milliseconds') + 'Z')
        시각s.append(data_row.시각.isoformat(timespec='milliseconds') + 'Z') # 시각s도 동일하게 포맷

        data_inflow2.append(data_row.유입유량2 if data_row.유입유량2 is not None else None)
        data_outflow2.append(data_row.유출유량2 if data_row.유출유량2 is not None else None)
        data_pred_outflow2.append(data_row.유출유량2_예측 if data_row.유출유량2_예측 is not None else None)
        data_gate7_rec.append(data_row.유입개도7_추천 if data_row.유입개도7_추천 is not None else None)
        data_gate8_rec.append(data_row.유입개도8_추천 if data_row.유입개도8_추천 is not None else None)
        data_inflow1.append(data_row.유입유량1 if data_row.유입유량1 is not None else None)
        data_outflow1.append(data_row.유출유량1 if data_row.유출유량1 is not None else None)
        data_pred_outflow1.append(data_row.유출유량1_예측 if data_row.유출유량1_예측 is not None else None)
        data_gate1_rec.append(data_row.유입개도1_추천 if data_row.유입개도1_추천 is not None else None)
        data_gate2_rec.append(data_row.유입개도2_추천 if data_row.유입개도2_추천 is not None else None)

        data_level1_actual.append(data_row.수위1 if data_row.수위1 is not None else None)
        data_level2_actual.append(data_row.수위2 if data_row.수위2 is not None else None)
        data_level7_actual.append(data_row.수위7 if data_row.수위7 is not None else None)
        data_level8_actual.append(data_row.수위8 if data_row.수위8 is not None else None)
        
        data_level1_info.append(data_row.수위1_정보 if data_row.수위1_정보 is not None else 'N/A')
        data_level2_info.append(data_row.수위2_정보 if data_row.수위2_정보 is not None else 'N/A')
        data_level7_info.append(data_row.수위7_정보 if data_row.수위7_정보 is not None else 'N/A')
        data_level8_info.append(data_row.수위8_정보 if data_row.수위8_정보 is not None else 'N/A')
        
        data_level1_pred.append(data_row.수위1_예측 if data_row.수위1_예측 is not None else None)
        data_level2_pred.append(data_row.수위2_예측 if data_row.수위2_예측 is not None else None)
        data_level7_pred.append(data_row.수위7_예측 if data_row.수위7_예측 is not None else None)
        data_level8_pred.append(data_row.수위8_예측 if data_row.수위8_예측 is not None else None)

        data_current_risk1.append(data_row.수위1_현재위험도 if data_row.수위1_현재위험도 is not None else None)
        data_current_risk2.append(data_row.수위2_현재위험도 if data_row.수위2_현재위험도 is not None else None)
        data_current_risk7.append(data_row.수위7_현재위험도 if data_row.수위7_현재위험도 is not None else None)
        data_current_risk8.append(data_row.수위8_현재위험도 if data_row.수위8_현재위험도 is not None else None)
        data_pred_risk1.append(data_row.수위1_예측위험도 if data_row.수위1_예측위험도 is not None else None)
        data_pred_risk2.append(data_row.수위2_예측위험도 if data_row.수위2_예측위험도 is not None else None)
        data_pred_risk7.append(data_row.수위7_예측위험도 if data_row.수위7_예측위험도 is not None else None)
        data_pred_risk8.append(data_row.수위8_예측위험도 if data_row.수위8_예측위험도 is not None else None)
        data_recovery_mode1.append(data_row.유입개도1_회복모드여부 if data_row.유입개도1_회복모드여부 is not None else None)
        data_recovery_mode2.append(data_row.유입개도2_회복모드여부 if data_row.유입개도2_회복모드여부 is not None else None)
        data_recovery_mode7.append(data_row.유입개도7_회복모드여부 if data_row.유입개도7_회복모드여부 is not None else None)
        data_recovery_mode8.append(data_row.유입개도8_회복모드여부 if data_row.유입개도8_회복모드여부 is not None else None)
        data_volume.append(data_row.체적 if data_row.체적 is not None else None) 

    valid_inflow2_data = [val for val in data_inflow2 if val is not None and val != '']
    if valid_inflow2_data : logging.info(f"ProD Min 유입유량2: {min(valid_inflow2_data)}, Max 유입유량2: {max(valid_inflow2_data)}")
    valid_inflow1_data = [val for val in data_inflow1 if val is not None and val != '']
    if valid_inflow1_data : logging.info(f"ProD Min 유입유량1: {min(valid_inflow1_data)}, Max 유입유량1: {max(valid_inflow1_data)}")

    return_data = {
        "labels": labels,
        "시각s": 시각s,
        "유입유량2": data_inflow2,
        "유출유량2": data_outflow2,
        "유출유량2_예측": data_pred_outflow2,
        "유입개도7_추천": data_gate7_rec,
        "유입개도8_추천": data_gate8_rec,
        "유입유량1": data_inflow1,
        "유출유량1": data_outflow1,
        "유출유량1_예측": data_pred_outflow1,
        "유입개도1_추천": data_gate1_rec,
        "유입개도2_추천": data_gate2_rec,
        "수위1": data_level1_actual, 
        "수위2": data_level2_actual,
        "수위7": data_level7_actual,
        "수위8": data_level8_actual,
        "수위1_정보": data_level1_info, 
        "수위2_정보": data_level2_info,
        "수위7_정보": data_level7_info,
        "수위8_정보": data_level8_info,
        "수위1_예측": data_level1_pred,
        "수위2_예측": data_level2_pred,
        "수위7_예측": data_level7_pred,
        "수위8_예측": data_level8_pred,
        "수위1_현재위험도": data_current_risk1,
        "수위2_현재위험도": data_current_risk2,
        "수위7_현재위험도": data_current_risk7,
        "수위8_현재위험도": data_current_risk8,
        "수위1_예측위험도": data_pred_risk1,
        "수위2_예측위험도": data_pred_risk2,
        "수위7_예측위험도": data_pred_risk7,
        "수위8_예측위험도": data_pred_risk8,
        "유입개도1_회복모드여부": data_recovery_mode1,
        "유입개도2_회복모드여부": data_recovery_mode2,
        "유입개도7_회복모드여부": data_recovery_mode7,
        "유입개도8_회복모드여부": data_recovery_mode8,
        "체적": data_volume 
    }

    logging.info(f"DEBUG_FINAL_JSON_DATA_PY (Chart/Event Log): {json.dumps(return_data, ensure_ascii=False, indent=2)}")

    return jsonify(return_data)


# CSV 다운로드 함수
@app.route('/download_data', methods=['GET'])
def download_data():
    selected_pro_d_str = request.args.get('pro_d_fields')
    start_date_str = request.args.get('startDate')
    end_date_str = request.args.get('endDate')

    if not selected_pro_d_str:
        return "선택된 데이터가 없습니다.", 400

    selected_pro_d_fields = selected_pro_d_str.split(',')

    try:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d') if start_date_str else None
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d') + timedelta(days=1) - timedelta(microseconds=1) if end_date_str else None
    except ValueError:
        return "날짜 형식이 올바르지 않습니다. YYYY-MM-DD 형식이어야 합니다.", 400

    pro_d_column_mapping = {
        '유입유량2': ProDData.유입유량2,
        '유출유량2': ProDData.유출유량2,
        '유출유량2_예측': ProDData.유출유량2_예측,
        '유입개도7_추천': ProDData.유입개도7_추천,
        '유입개도8_추천': ProDData.유입개도8_추천,
        '유입유량1': ProDData.유입유량1,
        '유출유량1': ProDData.유출유량1,
        '유출유량1_예측': ProDData.유출유량1_예측,
        '유입개도1_추천': ProDData.유입개도1_추천,
        '유입개도2_추천': ProDData.유입개도2_추천,
        '수위1': ProDData.수위1, 
        '수위2': ProDData.수위2,
        '수위7': ProDData.수위7,
        '수위8': ProDData.수위8,
        '수위1_정보': ProDData.수위1_정보,
        '수위2_정보': ProDData.수위2_정보,
        '수위7_정보': ProDData.수위7_정보,
        '수위8_정보': ProDData.수위8_정보,
        '수위1_예측': ProDData.수위1_예측,
        '수위2_예측': ProDData.수위2_예측,
        '수위7_예측': ProDData.수위7_예측,
        '수위8_예측': ProDData.수위8_예측,
        '수위1_현재위험도': ProDData.수위1_현재위험도,
        '수위2_현재위험도': ProDData.수위2_현재위험도,
        '수위7_현재위험도': ProDData.수위7_현재위험도,
        '수위8_현재위험도': ProDData.수위8_현재위험도,
        '수위1_예측위험도': ProDData.수위1_예측위험도,
        '수위2_예측위험도': ProDData.수위2_예측위험도,
        '수위7_예측위험도': ProDData.수위7_예측위험도,
        '수위8_예측위험도': ProDData.수위8_예측위험도,
        '유입개도1_회복모드여부': ProDData.유입개도1_회복모드여부,
        '유입개도2_회복모드여부': ProDData.유입개도2_회복모드여부,
        '유입개도7_회복모드여부': ProDData.유입개도7_회복모드여부,
        '유입개도8_회복모드여부': ProDData.유입개도8_회복모드여부,
        '체적': ProDData.체적, 
    }

    query_columns = [ProDData.시각]
    header_row = ['시각']

    for field_name in selected_pro_d_fields:
        if field_name == '시각':
            continue
        if field_name in pro_d_column_mapping:
            query_columns.append(pro_d_column_mapping[field_name])
            header_row.append(field_name)
        else:
            logging.warning(f"CSV 다운로드에 요청된 필드 '{field_name}'이 ProDData 컬럼 매핑에 없습니다. 건너뜁니다.")

    if len(query_columns) <= 1:
        return "다운로드할 유효한 데이터를 선택하지 않았습니다.", 400

    pro_d_records_query = db.session.query(*query_columns)

    if start_date:
        pro_d_records_query = pro_d_records_query.filter(ProDData.시각 >= start_date)
    if end_date:
        pro_d_records_query = pro_d_records_query.filter(ProDData.시각 <= end_date)

    pro_d_records = pro_d_records_query.order_by(ProDData.시각.asc()).all()

    si = io.StringIO()
    cw = csv.writer(si)

    cw.writerow(header_row)

    for record in pro_d_records:
        row_values = []
        for i, value in enumerate(record):
            if i == 0:
                row_values.append(value.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3])
            else:
                row_values.append(value)
        cw.writerow(row_values)

    output = si.getvalue()
    si.close()

    response = Response(output, mimetype="text/csv")
    response.headers["Content-Disposition"] = "attachment; filename=pro_d_data.csv"
    return response


if __name__ == '__main__':
    app_host = '0.0.0.0'
    app_port = 5000
    
    logging.info(f"Flask 애플리케이션이 http://{app_host}:{app_port} 에서 실행됩니다.")
    logging.info("웹 페이지에서 D 배수지 차트의 실시간 갱신 및 이벤트 로그 데이터를 확인해 주세요.")
    logging.info("데이터베이스 연결 설정 및 MySQL 서버 상태를 다시 한번 확인해 주세요.")
    
    app.run(debug=True, host=app_host, port=app_port)