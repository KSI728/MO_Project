// ==========================================================
// Custom alert modal functions
// ==========================================================
function showCustomAlert(title, message) {
    const modal = document.getElementById('customAlertModal');
    document.getElementById('customAlertTitle').innerText = title;
    document.getElementById('customAlertMessage').innerText = message;
    modal.style.display = 'flex'; // Set to flex for centering
    // 중앙 정렬을 위해 flex로 설정

    // Hide modal when close button is clicked
    // 닫기 버튼 클릭 시 모달 숨기기
    modal.querySelector('.alert-close-button').onclick = function() {
        modal.style.display = 'none';
    };

    // Hide modal when clicking outside of it
    // 모달 외부 클릭 시 모달 숨기기
    modal.onclick = function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    };
}

// ==========================================================
// Chart related functions
// ==========================================================
const charts = {};
let lastChartTime = null;
const MAX_DATA_POINTS = 6;

let isUpdatingChart = false; // Flag to prevent duplicate updates
// 중복 업데이트 방지를 위한 플래그

const CHART_COLORS = {
    actual: '#3B82F6', // Blue for actual data
    // 실제 데이터용 파란색
    predicted: '#FFD700', // Gold for predicted data
    // 예측 데이터용 금색
    red: 'rgb(255, 99, 132)',
    yellow: 'rgb(255, 206, 86)',
    green: 'rgb(75, 192, 192)'
};

// Helper function to format ISO 8601 string to HH:MM:SS
// ISO 8601 문자열을 HH:MM:SS 형식으로 포맷하는 헬퍼 함수
function formatTimeToHHMMSS(isoString) {
    if (!isoString) return '';
    const date = new Date(isoString);
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
}

// Helper function to format ISO 8601 string to YYYY. M. D | HH:MM:SS
// ISO 8601 문자열을 YYYY. M. D | HH:MM:SS 형식으로 포맷하는 헬퍼 함수
function formatToFullDateTime(isoString) {
    if (!isoString) return '';
    const date = new Date(isoString);
    const year = date.getFullYear();
    const month = date.getMonth() + 1; // getMonth() is 0-indexed
    // getMonth()는 0부터 시작
    const day = date.getDate();
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${year}. ${month}. ${day} | ${hours}:${minutes}:${seconds}`;
}

// Chart.js Plugin for Y-axis background colors
// Y축 배경색을 위한 Chart.js 플러그인
const yAxisBackgroundPlugin = {
    id: 'yAxisBackground',
    beforeDraw: (chart) => {
        const { ctx, chartArea, scales } = chart;
        const y = scales.y;

        // Define water level ranges and their colors
        // 수위 범위와 색상 정의
        const ranges = [
            { start: 95, end: y.max, color: CHART_COLORS.red.replace('rgb', 'rgba').replace(')', ',0.2)') }, // 95 이상 - 붉은색 계열
            { start: 91, end: 95, color: CHART_COLORS.yellow.replace('rgb', 'rgba').replace(')', ',0.2)') }, // 91 이상 95 미만 - 노란색 계열
            { start: 80, end: 91, color: CHART_COLORS.green.replace('rgb', 'rgba').replace(')', ',0.2)') }, // 80 이상 91 미만 - 초록색 계열
            { start: 65, end: 80, color: CHART_COLORS.yellow.replace('rgb', 'rgba').replace(')', ',0.2)') }, // 65 이상 80 미만 - 노란색 계열
            { start: y.min, end: 65, color: CHART_COLORS.red.replace('rgb', 'rgba').replace(')', ',0.2)') } // 65 미만 - 붉은색 계열
        ];

        ctx.save();
        ctx.beginPath();
        ctx.rect(chartArea.left, chartArea.top, chartArea.right - chartArea.left, chartArea.bottom - chartArea.top);
        ctx.clip();

        ranges.forEach(range => {
            // Ensure the range values are within the chart's y-axis min/max
            // 범위 값이 차트의 y축 최소/최대값 내에 있는지 확인
            const yStart = y.getPixelForValue(Math.min(Math.max(range.start, y.min), y.max));
            const yEnd = y.getPixelForValue(Math.min(Math.max(range.end, y.min), y.max));

            const top = Math.min(yStart, yEnd);
            const bottom = Math.max(yStart, yEnd);
            const height = bottom - top;

            ctx.fillStyle = range.color;
            ctx.fillRect(chartArea.left, top, chartArea.right - chartArea.left, height);
        });
        ctx.restore();
    }
};
Chart.register(yAxisBackgroundPlugin);

// Common chart options
// 공통 차트 옵션
const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    animation: {
        duration: 500 // Smooth animation for updates
        // 업데이트를 위한 부드러운 애니메이션
    },
    plugins: {
        legend: {
            display: true, // Show legend for Actual vs. Predicted
            // 실제값 vs 예측값 범례 표시
            labels: {
                color: "#E0E0E0" // Color for legend text
                // 범례 텍스트 색상
            }
        },
        tooltip: {
            mode: 'index',
            intersect: false,
            callbacks: {
                label: function(context) {
                    let label = context.dataset.label || '';
                    if (label) {
                        label += ': ';
                    }
                    if (context.parsed.y !== null) {
                        label += context.parsed.y.toFixed(2) + '%';
                    }
                    return label;
                },
                title: function(context) {
                    // 툴팁 제목을 시:분:초 형식으로만 표시
                    const isoString = context[0].label; // ISO 8601 string
                    return `시각: ${formatTimeToHHMMSS(isoString)}`;
                }
            }
        },
        yAxisBackground: { // Enable our custom plugin
            enabled: true
        }
    },
    scales: {
        x: {
            type: 'category',
            ticks: {
                color: '#E0E0E0',
                maxTicksLimit: MAX_DATA_POINTS, // X축 최대 출력 갯수
                callback: function(value, index, values) {
                    // X축 레이블을 시:분:초 형식으로만 표시
                    const isoString = this.getLabelForValue(value); // ISO 8601 string
                    return formatTimeToHHMMSS(isoString);
                }
            },
            grid: { color: 'rgba(255,255,255,0.1)' },
            title: {
                display: true,
                text: '시각',
                color: '#E0E0E0'
            }
        },
        y: {
            ticks: {
                color: '#E0E0E0',
                beginAtZero: false,
                callback: function(value, index, values) {
                    return value + '%';
                }
            },
            grid: { color: 'rgba(255,255,255,0.1)' },
            min: 60, // Set fixed min for Y-axis
            // Y축 최소값 고정
            max: 100 // Set fixed max for Y-axis
            // Y축 최대값 고정
        }
    }
};

// Mapping canvas IDs to data keys for actual and predicted values
// 실제값 및 예측값을 위한 캔버스 ID와 데이터 키 매핑
const chartTankMapping = {
    'chart1': { actual: '수위1', predicted: '수위1_예측' }, // '수위1' for actual, '수위1_예측' for predicted
    'chart2': { actual: '수위2', predicted: '수위2_예측' },
    'chart7': { actual: '수위7', predicted: '수위7_예측' },
    'chart8': { actual: '수위8', predicted: '수위8_예측' },
};

function createOrUpdateCharts(data) {
    if (isUpdatingChart) {
        console.log("createOrUpdateCharts: Chart update is already in progress. Ignoring new request.");
        return;
    }
    isUpdatingChart = true;

    ['chart1', 'chart2', 'chart7', 'chart8'].forEach(id => {
        let ctx = document.getElementById(id);
        if (!ctx || ctx.tagName !== 'CANVAS') {
            console.warn(`Canvas element with ID '${id}' not found or is not a canvas. Attempting to re-create.`);
            const card = document.querySelector(`#${id}`).closest('.chart-card');
            if (card) {
                const originalH3Text = card.querySelector('h3') ? card.querySelector('h3').innerText : '수위';
                card.innerHTML = `
                            <h3>${originalH3Text}</h3>
                            <div class="unit-label">단위: %</div>
                            <canvas id="${id}"></canvas>
                        `;
                ctx = document.getElementById(id);
                if (!ctx) {
                    console.error(`Failed to re-create canvas element with ID '${id}'. Skipping chart initialization.`);
                    return;
                }
            } else {
                console.error(`Could not find parent .chart-card for canvas ID '${id}'. Skipping chart initialization.`);
                return;
            }
        }

        const tankKeys = chartTankMapping[id];

        if (charts[id]) { // If chart instance already exists, update it
            // 차트 인스턴스가 이미 존재하면 업데이트
            const chart = charts[id];

            // Add new data
            // 새 데이터 추가
            data.labels.forEach((label, index) => {
                chart.data.labels.push(label); // Keep full ISO string in labels for internal use
                // 내부 사용을 위해 ISO 전체 문자열을 레이블에 유지
                chart.data.datasets[0].data.push(data[tankKeys.actual][index]); // Actual data
                // 실제 데이터
                chart.data.datasets[1].data.push(data[tankKeys.predicted][index]); // Predicted data
                // 예측 데이터
            });

            // Maintain max data points by removing old data
            // 이전 데이터를 제거하여 최대 데이터 포인트 유지
            while (chart.data.labels.length > MAX_DATA_POINTS) {
                chart.data.labels.shift();
                chart.data.datasets[0].data.shift();
                chart.data.datasets[1].data.shift();
            }
            chart.update();
        } else { // If no chart instance, create a new one (on initial load)
            // 차트 인스턴스가 없으면 새로 생성 (초기 로드 시)
            charts[id] = new Chart(ctx.getContext('2d'), {
                type: 'line',
                data: {
                    // Slice data to initially display only MAX_DATA_POINTS
                    // 초기에는 MAX_DATA_POINTS만 표시하도록 데이터 슬라이싱
                    labels: data.labels.slice(-MAX_DATA_POINTS), // Use full ISO string as labels
                    // 전체 ISO 문자열을 레이블로 사용
                    datasets: [
                        {
                            label: '실제 수위',
                            data: data[tankKeys.actual].slice(-MAX_DATA_POINTS),
                            backgroundColor: CHART_COLORS.actual.replace('rgb', 'rgba').replace(')', ',0.1)'),
                            borderColor: CHART_COLORS.actual,
                            borderWidth: 2,
                            pointRadius: 4,
                            fill: false,
                            tension: 0.4
                        },
                        {
                            label: '예측 수위',
                            data: data[tankKeys.predicted].slice(-MAX_DATA_POINTS),
                            backgroundColor: CHART_COLORS.predicted.replace('rgb', 'rgba').replace(')', ',0.1)'),
                            borderColor: CHART_COLORS.predicted,
                            borderWidth: 2,
                            pointRadius: 4,
                            fill: false,
                            tension: 0.4
                        }
                    ]
                },
                options: chartOptions
            });
        }
    });

    if (data.시각s && data.시각s.length > 0) {
        lastChartTime = data.시각s[data.시각s.length - 1];
    }
    isUpdatingChart = false;
}

function updateCharts() {
    if (isUpdatingChart) {
        console.log("updateCharts: Chart update is already in progress. Ignoring new fetch request.");
        return;
    }

    const currentLastTime = lastChartTime === null ? 'null' : lastChartTime;

    fetch(`/get_latest_pro_d_chart_data?last_time=${currentLastTime}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                console.error("Chart data loading error:", data.error);
                // Destroy existing charts and display error message
                // 기존 차트 파괴 및 오류 메시지 표시
                Object.values(charts).forEach(chart => {
                    if (chart) chart.destroy();
                });
                Object.keys(charts).forEach(key => delete charts[key]);
                document.querySelectorAll('.chart-card').forEach(card => {
                    const originalH3 = card.querySelector('h3') ? card.querySelector('h3').innerText : '수위';
                    card.innerHTML = `
                            <h3>${originalH3}</h3>
                            <div class="unit-label">단위: %</div>
                            <p style="color: red; text-align: center;">데이터 로드 실패: ${data.error}</p>
                        `;
                });
                isUpdatingChart = false;
                return;
            }

            if (data.labels && data.labels.length > 0) {
                createOrUpdateCharts(data);

                // "현재시간" 표시를 ISO 8601 문자열에서 원하는 형식으로 포맷팅
                const latestTimestamp = data.labels[data.labels.length - 1];
                document.getElementById('nowTime').textContent = formatToFullDateTime(latestTimestamp);

                lastChartTime = data.시각s[data.시각s.length - 1];
            } else {
                console.log("No new data or data.labels is empty. Keeping current chart state.");
            }
            isUpdatingChart = false;
        })
        .catch(error => {
            console.error("Network or parsing error during chart data refresh:", error);
            // Destroy existing charts and display error message
            // 기존 차트 파괴 및 오류 메시지 표시
            Object.values(charts).forEach(chart => {
                if (chart) chart.destroy();
            });
            Object.keys(charts).forEach(key => delete charts[key]);
            document.querySelectorAll('.chart-card').forEach(card => {
                const originalH3 = card.querySelector('h3') ? card.querySelector('h3').innerText : '수위';
                card.innerHTML = `
                            <h3>${originalH3}</h3>
                            <div class="unit-label">단위: %</div>
                            <p style="color: red; text-align: center;">네트워크 오류: ${error.message}</p>
                        `;
            });
            isUpdatingChart = false;
        });
}

window.onload = function() {
    updateCharts();
};
setInterval(updateCharts, 10000);


// ==========================================================
// Download modal functionality
// ==========================================================
const downloadButton = document.getElementById('downloadButton');
const downloadModal = document.getElementById('downloadModal');
const closeButton = document.querySelector('.close-button');
const selectAllCheckbox = document.getElementById('selectAllTanks');
const tankCheckboxes = document.querySelectorAll('.tank-checkbox');
const modalStartDate = document.getElementById('modalStartDate');
const modalEndDate = document.getElementById('modalEndDate');
const downloadCsvButton = document.getElementById('downloadCsvButton');

downloadButton.onclick = function() {
    downloadModal.style.display = 'flex';
};

closeButton.onclick = function() {
    downloadModal.style.display = 'none';
};

window.onclick = function(event) {
    if (event.target == downloadModal) {
        downloadModal.style.display = 'none';
    }
};

selectAllCheckbox.onchange = function() {
    tankCheckboxes.forEach(checkbox => {
        checkbox.checked = this.checked;
    });
};

tankCheckboxes.forEach(checkbox => {
    checkbox.onchange = function() {
        if (!this.checked) {
            selectAllCheckbox.checked = false;
        } else {
            const allChecked = Array.from(tankCheckboxes).every(cb => cb.checked);
            selectAllCheckbox.checked = allChecked;
        }
    };
});

downloadCsvButton.onclick = function() {
    const selectedFields = Array.from(tankCheckboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.value);

    const startDate = modalStartDate.value;
    const endDate = modalEndDate.value;

    if (selectedFields.length === 0) {
        showCustomAlert("선택 오류", "다운로드할 데이터를 최소 하나 이상 선택해주세요.");
        return;
    }
    if (!startDate || !endDate) {
        showCustomAlert("기간 오류", "기간을 선택해주세요.");
        return;
    }

    const downloadUrl = `/download_data?pro_d_fields=${selectedFields.join(',')}&startDate=${startDate}&endDate=${endDate}`;
    window.location.href = downloadUrl;

    downloadModal.style.display = 'none';
};

// Setting dynamic date range (example based on current time)
// 동적 날짜 범위 설정 (현재 시간을 기반으로 한 예시)
const today = new Date();
const yyyy = today.getFullYear();
const mm = String(today.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
// 월은 0부터 시작
const dd = String(today.getDate()).padStart(2, '0');
const todayStr = `${yyyy}-${mm}-${dd}`;

const minDate = "2024-09-16"; // Your actual earliest data date
// 실제 가장 빠른 데이터 날짜
const maxDate = todayStr; // Current date
// 현재 날짜

modalStartDate.min = minDate;
modalStartDate.max = maxDate;
modalEndDate.min = minDate;
modalEndDate.max = maxDate;
modalStartDate.value = minDate;
modalEndDate.value = maxDate;