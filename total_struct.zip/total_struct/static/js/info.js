// Current time display (will be used for non-D reservoirs)
// 현재 시간 표시 (D 배수지가 아닐 때 사용됨)
function updateTime() {
    const now = new Date();
    const dateStr = `${now.getFullYear()}. ${String(now.getMonth() + 1).padStart(2, '0')}. ${String(now.getDate()).padStart(2, '0')} | ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    document.getElementById('nowTime').textContent = dateStr;
}
// Do NOT setInterval here initially. It will be managed by updateReservoir.
// 초기에는 여기에 setInterval을 설정하지 마십시오. updateReservoir에서 관리됩니다.
// setInterval(updateTime, 1000); // Remove this line from here
// updateTime(); // Remove this line from here

let currentTimestampInterval = null; // To hold the interval for the current time
// 현재 시간 간격을 저장할 변수

// Operation mode modal functions
// 운영 모드 모달 함수
function openModal() {
    document.getElementById("modeModal").style.display = "block";
}

function closeModal() {
    document.getElementById("modeModal").style.display = "none";
}

// Show/hide input fields when manual mode is selected
// 수동 모드 선택 시 입력 필드 표시/숨기기
document.getElementById("modeSelect").addEventListener("change", function () {
    const isManual = this.value === "manual";
    document.getElementById("manualRangeInputs").style.display = isManual ? "block" : "none";
});

// Apply operation mode and update badge
// 운영 모드 적용 및 배지 업데이트
function applyMode() {
    const mode = document.getElementById("modeSelect").value;
    const modeBadge = document.getElementById("modeBadge");

    if (mode === "manual") {
        modeBadge.textContent = "🛠 수동 모드 작동 중";
        modeBadge.classList.remove('badge-info');
        modeBadge.classList.add('badge-warning');
    } else {
        modeBadge.textContent = "⚙️ AI 자율 운영 중";
        modeBadge.classList.remove('badge-warning');
        modeBadge.classList.add('badge-info');
    }
    closeModal();
}

// Global variables
// 전역 변수
let inflowChartObj = null;
let outflowChartObj = null;
let currentInflowGraphIndex = 0; // Current index for inflow chart (0: inflow1, 1: inflow2)
// 유입유량 차트의 현재 인덱스 (0: 유입유량1, 1: 유입유량2)
let currentOutflowGraphIndex = 0; // Current index for outflow chart (0: outflow1, 1: outflow2)
// 유출유량 차트의 현재 인덱스 (0: 유출유량1, 1: 유출유량2)
let currentReservoirName = 'A'; // Initial reservoir set to A
// 초기 배수지 A로 설정

// Global variables for ProDData
// ProDData를 위한 전역 변수
let proDInterval = null;
let lastKnownTimestamp = null; // Last timestamp for backend communication
// 백엔드 통신을 위한 마지막 타임스탬프

// Data cache for D reservoir to switch between inflow1/2 and outflow1/2 charts
// D 배수지용 데이터 캐시 (유입유량1/2 및 유출유량1/2 차트 전환용)
let dReservoirChartData = {
    inflow1: { labels: [], data: [], color: "#1f8ef1", label: "유입유량1" },
    inflow2: { labels: [], data: [], color: "#2dce89", label: "유입유량2" },
    outflow1: { labels: [], data: [], predData: [], color: "#ba54f5", predColor: "#ff8d72", label: "유출유량1", predLabel: "유출유량1 예측" },
    outflow2: { labels: [], data: [], predData: [], color: "#6a0dad", predColor: "#e6e6fa", label: "유출유량2", predLabel: "유출유량2 예측" }
};


// Chart creation function (using Chart.js)
// 차트 생성 함수 (Chart.js 사용)
const createChart = (id, labels, datasets) => new Chart(
    document.getElementById(id).getContext("2d"), {
        type: 'line',
        data: {
            labels: labels,
            datasets: datasets
        },
        options: {
            maintainAspectRatio: false,
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: "#9e9e9e" },
                    grid: { color: 'rgba(29,140,248,0.1)' },
                    title: { // Y축 단위 추가
                        display: true,
                        text: 'm³/5min', // 단위 텍스트
                        color: '#fff' // 단위 텍스트 색상
                    }
                },
                x: {
                    ticks: {
                        color: "#9e9e9e",
                        autoSkip: true,
                        maxTicksLimit: 5 // x축 눈금을 최대 5개로 제한
                    },
                    grid: { color: 'rgba(220,220,220,0.1)' }
                }
            },
            plugins: {
                legend: { display: true, labels: { color: "#fff" } }
            },
            animation: {
                duration: 0
            }
        }
    }
);

// Schematic image paths by reservoir
// 배수지별 모식도 이미지 경로
const schematicImages = {
    A: "/static/images/None.png",
    B: "/static/images/None.png",
    C: "/static/images/None.png",
    D: "/static/images/DM.png",
    E: "/static/images/None.png",
    F: "/static/images/None.png",
    G: "/static/images/GM.png",
    H: "/static/images/HM.png"
};

// Dummy data for reservoirs (D reservoir uses real-time ProDData)
// 배수지 더미 데이터 (D 배수지는 실시간 ProDData 사용)
const reservoirStaticData = {
    A: {
        status: "상승 중 ↑",
        overview: { level: "5.2 m", inflow: "42 m³/h", outflow: "38 m³/h", status: "안정" },
        inflowData: [
            { label: "유입유량1", data: [53, 20, 10, 80, 100, 45, 60], color: "#1f8ef1" },
            { label: "유입유량2", data: [65, 40, 30, 90, 120, 50, 55], color: "#2dce89" }
        ],
        outflowData: [
            { label: "유출유량1", data: [30, 40, 20, 70, 90, 50, 70], color: "#ba54f5" },
            { label: "유출유량2", data: [20, 30, 25, 60, 85, 55, 65], color: "#ff8d72" }
        ],
        labels: ['12AM', '4AM', '8AM', '12PM', '4PM', '8PM', '11PM']
    },
    B: {
        status: "하강 중 ↓",
        overview: { level: "4.3 m", inflow: "33 m³/h", outflow: "45 m³/h", status: "주의" },
        inflowData: [{ label: "유입유량1", data: [20, 25, 35, 50, 60, 40, 20], color: "#1f8ef1" }],
        outflowData: [{ label: "유출유량1", data: [25, 30, 40, 55, 65, 35, 20], color: "#ba54f5" }],
        labels: ['12AM', '4AM', '8AM', '12PM', '4PM', '8PM', '11PM']
    },
    C: {
        status: "안정",
        overview: { level: "7.0 m", inflow: "60 m³/h", outflow: "55 m³/h", status: "정상" },
        inflowData: [{ label: "유입유량1", data: [50, 55, 60, 65, 70, 60, 50], color: "#1f8ef1" }],
        outflowData: [{ label: "유출유량1", data: [45, 50, 55, 60, 65, 50, 40], color: "#ba54f5" }],
        labels: ['12AM', '4AM', '8AM', '12PM', '4PM', '8PM', '11PM']
    },
    D: { // D reservoir uses real-time ProDData, so initial data is empty
        // D 배수지는 실시간 ProDData를 사용하므로 초기 데이터는 비어 있습니다.
        status: "데이터 로딩 중...", // This will be replaced by percentage
        // 데이터 로딩 중... (퍼센트로 대체될 예정)
        overview: {
            type: "facility", // Indicate that this is facility data
            // 시설 데이터임을 나타냄
            data: [
                { label: "시설용량", value: "23,600㎥" },
                { label: "평균 급수량", value: "36,761 ㎥/일" },
                { label: "최대 급수량", value: "187,919 ㎥/일" },
                { label: "비상시 급수일수", value: "3일" }
            ]
        },
        inflowData: [{ label: "유입유량1", data: [], color: "#1f8ef1" }], // Start with empty data
        // 빈 데이터로 시작
        outflowData: [{ label: "유출유량1", data: [], color: "#ba54f5", predLabel: "유출유량1 예측", predColor: "#ff8d72" }], // Start with empty data
        // 빈 데이터로 시작
        labels: [] // Initial labels are empty (filled with real-time data)
        // 초기 레이블은 비어 있음 (실시간 데이터로 채워짐)
    },
    E: {
        status: "하강 중 ↓",
        overview: { level: "3.8 m", inflow: "25 m³/h", outflow: "30 m³/h", status: "경고" },
        inflowData: [{ label: "유입유량1", data: [15, 20, 25, 30, 35, 20, 10], color: "#1f8ef1" }],
        outflowData: [{ label: "유출유량1", data: [20, 25, 30, 35, 40, 25, 15], color: "#ba54f5" }],
        labels: ['12AM', '4AM', '8AM', '12PM', '4PM', '8PM', '11PM']
    },
    F: {
        status: "안정",
        overview: { level: "6.0 m", inflow: "40 m³/h", outflow: "40 m³/h", status: "정상" },
        inflowData: [{ label: "유입유량1", data: [35, 38, 40, 42, 40, 38, 35], color: "#1f8ef1" }],
        outflowData: [{ label: "유출유량1", data: [30, 35, 40, 45, 40, 35, 30], color: "#ba54f5" }],
        labels: ['12AM', '4AM', '8AM', '12PM', '4PM', '8PM', '11PM']
    },
    G: {
        status: "변동 중 ↕",
        overview: { level: "6.1 m", inflow: "52 m³/h", outflow: "49 m³/h", status: "주의" },
        inflowData: [{ label: "유입유량1", data: [40, 45, 55, 60, 75, 65, 50], color: "#1f8ef1" }],
        outflowData: [{ label: "유출유량1", data: [30, 35, 40, 55, 65, 50, 45], color: "#ba54f5" }],
        labels: ['12AM', '4AM', '8AM', '12PM', '4PM', '8PM', '11PM']
    },
    H: {
        status: "상승 중 ↑",
        overview: { level: "6.5 m", inflow: "58 m³/h", outflow: "55 m³/h", status: "안정" },
        inflowData: [{ label: "유입유량1", data: [60, 50, 45, 70, 90, 60, 50], color: "#1f8ef1" }],
        outflowData: [{ label: "유출유량1", data: [40, 50, 55, 60, 70, 50, 45], color: "#ba54f5" }],
        labels: ['12AM', '4AM', '8AM', '12PM', '4PM', '8PM', '11PM']
    }
};

// Function to update and redraw charts (used for static data)
// 차트 업데이트 및 다시 그리기 함수 (정적 데이터용)
function updateChartWithNewData(chartObjRef, dataIndex, reservoirSpecificData) {
    // Destroy existing chart to prevent memory leaks
    // 메모리 누수 방지를 위해 기존 차트 파괴
    if (chartObjRef === inflowChartObj && inflowChartObj) inflowChartObj.destroy();
    if (chartObjRef === outflowChartObj && outflowChartObj) outflowChartObj.destroy();

    const dataToDisplay = reservoirSpecificData[dataIndex];
    const datasets = [{
        label: dataToDisplay.label,
        data: dataToDisplay.data,
        fill: true,
        backgroundColor: dataToDisplay.color + '33',
        borderColor: dataToDisplay.color,
        borderWidth: 2,
        pointBackgroundColor: dataToDisplay.color,
        tension: 0.4
    }];

    // Add prediction dataset if available (for static data, this block usually won't execute)
    // 예측 데이터셋이 있는 경우 추가 (정적 데이터의 경우 이 블록은 일반적으로 실행되지 않음)
    if (dataToDisplay.predLabel && dataToDisplay.predData) {
        datasets.push({
            label: dataToDisplay.predLabel,
            data: dataToDisplay.predData,
            fill: false,
            borderColor: dataToDisplay.predColor,
            borderWidth: 2,
            borderDash: [5, 5], // Dashed line
            // 점선
            pointBackgroundColor: dataToDisplay.predColor,
            tension: 0.4
        });
    }

    // Create and assign new chart to global variable
    // 새 차트를 생성하고 전역 변수에 할당
    if (reservoirSpecificData === reservoirStaticData[currentReservoirName].inflowData) {
        inflowChartObj = createChart('chartInflow0', reservoirStaticData[currentReservoirName].labels, datasets);
    } else {
        outflowChartObj = createChart('chartOutflow0', reservoirStaticData[currentReservoirName].labels, datasets);
    }
}

// Handle switching between inflow/outflow charts (for both static and dynamic data)
// 유입/유출 차트 전환 처리 (정적 및 동적 데이터 모두)
function switchChart(type, direction) {
    if (currentReservoirName === 'D') {
        // For D reservoir, switch between inflow1/2 and outflow1/2 dynamic charts
        // D 배수지의 경우, 유입유량1/2 및 유출유량1/2 동적 차트 간 전환
        const maxPoints = 20; // Ensure consistency with updateProDCharts
        // updateProDCharts와의 일관성 유지

        if (type === 'inflow') {
            currentInflowGraphIndex = (currentInflowGraphIndex + direction + 2) % 2; // Cycle between 0 and 1
            // 0과 1 사이를 순환
            const targetInflowData = currentInflowGraphIndex === 0 ? dReservoirChartData.inflow1 : dReservoirChartData.inflow2;

            if (inflowChartObj) inflowChartObj.destroy(); // Destroy current inflow chart
            // 현재 유입유량 차트 파괴
            inflowChartObj = createChart('chartInflow0', targetInflowData.labels, [{
                label: targetInflowData.label,
                data: targetInflowData.data,
                borderColor: targetInflowData.color,
                backgroundColor: targetInflowData.color + '33',
                fill: true,
                tension: 0.4
            }]);
            document.getElementById("inflowTitle").innerText = targetInflowData.label;

        } else { // outflow
            currentOutflowGraphIndex = (currentOutflowGraphIndex + direction + 2) % 2; // Cycle between 0 and 1
            // 0과 1 사이를 순환
            const targetOutflowData = currentOutflowGraphIndex === 0 ? dReservoirChartData.outflow1 : dReservoirChartData.outflow2;

            if (outflowChartObj) outflowChartObj.destroy(); // Destroy current outflow chart
            // 현재 유출유량 차트 파괴
            outflowChartObj = createChart('chartOutflow0', targetOutflowData.labels, [{
                label: targetOutflowData.label,
                data: targetOutflowData.data,
                borderColor: targetOutflowData.color,
                backgroundColor: targetOutflowData.color + '33',
                fill: true,
                tension: 0.4
            }, {
                label: targetOutflowData.predLabel,
                data: targetOutflowData.predData,
                borderColor: targetOutflowData.predColor,
                borderDash: [5, 5],
                fill: false,
                tension: 0.4
            }]);
            document.getElementById("outflowTitle").innerText = targetOutflowData.label + (targetOutflowData.predLabel ? " 및 예측" : "");
        }
    } else {
        // For other reservoirs, use static data switching as before
        // 다른 배수지의 경우, 이전과 같이 정적 데이터 전환 사용
        const data = reservoirStaticData[currentReservoirName];

        if (type === 'inflow') {
            currentInflowGraphIndex = (currentInflowGraphIndex + direction + data.inflowData.length) % data.inflowData.length;
            document.getElementById("inflowTitle").innerText = data.inflowData[currentInflowGraphIndex].label;
            updateChartWithNewData(inflowChartObj, currentInflowGraphIndex, data.inflowData);
        } else { // outflow
            currentOutflowGraphIndex = (currentOutflowGraphIndex + direction + data.outflowData.length) % data.outflowData.length;
            document.getElementById("outflowTitle").innerText = data.outflowData[currentOutflowGraphIndex].label;
            updateChartWithNewData(outflowChartObj, currentOutflowGraphIndex, data.outflowData);
        }
    }
}

// Update reservoir information and charts
// 배수지 정보 및 차트 업데이트
function updateReservoir(reservoirName) {
    currentReservoirName = reservoirName;
    const data = reservoirStaticData[reservoirName];
    const deepinfoDButton = document.getElementById('deepinfoDButton');
    const proDOverlay = document.getElementById('prod-overlay-data');
    const eventLogCard = document.getElementById('eventLogCard');
    const eventLogTableBody = document.getElementById('eventLogTableBody');
    const overviewTableBody = document.querySelector('#overviewTable tbody');

    // NEW IDs for tank status visualization
    // 수조 상태 시각화를 위한 새로운 ID
    const tankLevelFillOrAnimation = document.getElementById('tank-level-fill-or-or-animation');
    const tankInfoDisplayText = document.getElementById('tank-info-display-text');


    // Common information updates
    // 공통 정보 업데이트
    document.getElementById('reservoir-title').textContent = `${reservoirName} 배수지 종합상황판`;


    // --- HANDLE CURRENT TIME DISPLAY ---
    // --- 현재 시간 표시 처리 ---
    if (currentTimestampInterval) {
        clearInterval(currentTimestampInterval); // Clear any existing interval
        // 기존 간격 지우기
        currentTimestampInterval = null;
    }

    if (reservoirName === 'D') {
        // For D reservoir, the time will be updated by fetchProDData
        // D 배수지의 경우 시간은 fetchProDData에 의해 업데이트됩니다.
        document.getElementById('nowTime').textContent = '데이터 시각 로딩 중...';
    } else {
        // For other reservoirs, display the current local time
        // 다른 배수지의 경우 현재 현지 시간 표시
        updateTime(); // Call once immediately
        // 즉시 한 번 호출
        currentTimestampInterval = setInterval(updateTime, 1000); // Start updating current time every second
        // 1초마다 현재 시간 업데이트 시작
    }
    // --- END HANDLE CURRENT TIME DISPLAY ---
    // --- 현재 시간 표시 처리 끝 ---


    // --- OVERVIEW SECTION UPDATE LOGIC ---
    // --- 개요 섹션 업데이트 로직 ---
    overviewTableBody.innerHTML = ''; // Clear existing overview rows
    // 기존 개요 행 지우기
    if (data.overview.type === "facility") {
        data.overview.data.forEach(item => {
            const row = overviewTableBody.insertRow();
            const th = document.createElement('th');
            th.setAttribute('scope', 'row');
            th.classList.add('pr-4');
            th.textContent = item.label;
            row.appendChild(th);
            const td = document.createElement('td');
            td.textContent = item.value;
            row.appendChild(td);
        });
        // For D reservoir (facility type), reset visualizer for dynamic volume update
        // D 배수지 (시설 유형)의 경우 동적 볼륨 업데이트를 위해 시각화 도구 재설정
        tankLevelFillOrAnimation.style.display = 'block';
        tankLevelFillOrAnimation.style.height = '0%'; // Initial height for D reservoir volume fill
        // D 배수지 볼륨 채우기를 위한 초기 높이
        tankInfoDisplayText.textContent = '데이터 로딩 중...'; // Initial text for D reservoir
        // D 배수지 초기 텍스트
        tankInfoDisplayText.style.fontSize = '2em'; // Adjust font size for percentage
        // 퍼센트 글꼴 크기 조정
        tankInfoDisplayText.style.color = '#00d6b4'; // Default color for percentage
        // 퍼센트 기본 색상
        tankLevelFillOrAnimation.querySelector('path').setAttribute('fill', 'rgba(0,213,180,0.4)'); // Default wave color
        // 기본 파동 색상
        tankLevelFillOrAnimation.querySelector('svg').style.display = 'block'; // Ensure wave is visible for D
        // D 배수지에서 파동이 보이는지 확인

    } else { // Default dynamic overview for A, B, C, etc.
        // A, B, C 등의 기본 동적 개요
        const overviewHtml = `
            <tr><th class="pr-4">수위</th><td id="overview-level">${data.overview.level}</td></tr>
            <tr><th>유입유량</th><td id="overview-inflow">${data.overview.inflow}</td></tr>
            <tr><th>유출유량</th><td id="overview-outflow">${data.overview.outflow}</td></tr>
            <tr><th>상태</th><td id="overview-status">${data.overview.status}</td></tr>
        `;
        overviewTableBody.innerHTML = overviewHtml;

        // Show water level animation for other reservoirs and set status text
        // 다른 배수지의 수위 애니메이션 표시 및 상태 텍스트 설정
        tankLevelFillOrAnimation.style.display = 'block';
        tankInfoDisplayText.textContent = data.status; // Set status text for other reservoirs
        // 다른 배수지 상태 텍스트 설정
        tankInfoDisplayText.style.fontSize = '1.2em'; // Adjust font size for status text
        // 상태 텍스트 글꼴 크기 조정
        tankInfoDisplayText.style.color = '#00d6b4'; // Default color for status text
        // 상태 텍스트 기본 색상


        const levelValue = parseFloat(data.overview.level);
        const maxLevel = 7.5; // Max level for other reservoirs
        // 다른 배수지의 최대 수위
        const waterHeight = (isNaN(levelValue) ? 50 : (levelValue / maxLevel) * 100);
        tankLevelFillOrAnimation.style.height = `${Math.min(waterHeight, 100)}%`;

        let waterColor = 'rgba(0,213,180,0.4)';
        if (data.overview.status.includes('주의')) {
            waterColor = 'rgba(255,165,0,0.4)';
        } else if (data.overview.status.includes('경고')) {
            waterColor = 'rgba(255,0,0,0.4)';
        }
        tankLevelFillOrAnimation.querySelector('path').setAttribute('fill', waterColor);
        tankLevelFillOrAnimation.querySelector('svg').style.display = 'block'; // Ensure wave is visible
        // 파동이 보이는지 확인
    }
    // --- END OVERVIEW SECTION UPDATE LOGIC ---
    // --- 개요 섹션 업데이트 로직 끝 ---


    // Update schematic image
    // 모식도 이미지 업데이트
    const schematicPath = schematicImages[reservoirName] || "/static/images/None.png";
    document.getElementById("schematicImage").src = schematicPath;

    // ProD (D Reservoir) specific logic
    // ProD (D 배수지) 특정 로직
    if (reservoirName === 'D') {
        deepinfoDButton.style.display = 'block';
        proDOverlay.style.display = 'block';
        eventLogCard.style.display = 'block'; // Show event log for D reservoir
        // D 배수지 이벤트 로그 표시

        // Stop existing interval if any
        // 기존 간격이 있으면 중지
        if (proDInterval) {
            clearInterval(proDInterval);
            proDInterval = null;
        }
        lastKnownTimestamp = null; // Reset timestamp for new time series start
        // 새 시계열 시작을 위해 타임스탬프 재설정

        // Reset D reservoir chart data cache
        // D 배수지 차트 데이터 캐시 재설정
        dReservoirChartData.inflow1 = { labels: [], data: [], color: "#1f8ef1", label: "유입유량1" };
        dReservoirChartData.inflow2 = { labels: [], data: [], color: "#2dce89", label: "유입유량2" };
        dReservoirChartData.outflow1 = { labels: [], data: [], predData: [], color: "#ba54f5", predColor: "#ff8d72", label: "유출유량1", predLabel: "유출유량1 예측" };
        dReservoirChartData.outflow2 = { labels: [], data: [], predData: [], color: "#6a0dad", predColor: "#e6e6fa", label: "유출유량2", predLabel: "유출유량2 예측" };

        // Destroy and nullify existing charts for a clean start
        // 깔끔한 시작을 위해 기존 차트 파괴 및 초기화
        if (inflowChartObj) inflowChartObj.destroy();
        if (outflowChartObj) outflowChartObj.destroy();
        inflowChartObj = null;
        outflowChartObj = null;

        // Initialize charts for D reservoir with empty data, showing only first inflow/outflow by default
        // D 배수지 차트를 빈 데이터로 초기화하고 기본적으로 첫 번째 유입/유출만 표시
        inflowChartObj = createChart('chartInflow0', dReservoirChartData.inflow1.labels, [{
            label: dReservoirChartData.inflow1.label,
            data: dReservoirChartData.inflow1.data,
            borderColor: dReservoirChartData.inflow1.color,
            backgroundColor: dReservoirChartData.inflow1.color + '33',
            fill: true,
            tension: 0.4
        }]);
        document.getElementById("inflowTitle").innerText = dReservoirChartData.inflow1.label;
        currentInflowGraphIndex = 0; // Ensure index is reset
        // 인덱스가 재설정되었는지 확인

        outflowChartObj = createChart('chartOutflow0', dReservoirChartData.outflow1.labels, [{
            label: dReservoirChartData.outflow1.label,
            data: dReservoirChartData.outflow1.data,
            borderColor: dReservoirChartData.outflow1.color,
            backgroundColor: dReservoirChartData.outflow1.color + '33',
            fill: true,
            tension: 0.4
        }, {
            label: dReservoirChartData.outflow1.predLabel,
            data: dReservoirChartData.outflow1.predData,
            borderColor: dReservoirChartData.outflow1.predColor,
            borderDash: [5, 5],
            fill: false,
            tension: 0.4
        }]);
        document.getElementById("outflowTitle").innerText = dReservoirChartData.outflow1.label + " 및 예측";
        currentOutflowGraphIndex = 0; // Ensure index is reset
        // 인덱스가 재설정되었는지 확인

        // Fetch initial data for D reservoir and start refreshing
        // D 배수지 초기 데이터 가져오기 및 새로 고침 시작
        fetchProDData(true);
        proDInterval = setInterval(fetchProDData, 10000); // Start refreshing data every 10 seconds
        // 10초마다 데이터 새로 고침 시작
        console.log("ProD data fetching started for D reservoir.");

        // Start event log updates for D reservoir
        // D 배수지 이벤트 로그 업데이트 시작
        eventLogTableBody.innerHTML = ''; // Clear existing logs
        // 기존 로그 지우기
        startEventLogUpdates(); // 이 함수는 fetchProDData와 독립적으로 작동하도록 수정 (아래 참고)

    } else { // For other reservoirs
        // 다른 배수지의 경우
        deepinfoDButton.style.display = 'none';
        proDOverlay.style.display = 'none';
        eventLogCard.style.display = 'none'; // Hide event log for non-D reservoirs
        // D 배수지가 아닌 경우 이벤트 로그 숨기기

        // Stop ProD data refreshing interval
        // ProD 데이터 새로 고침 간격 중지
        if (proDInterval) {
            clearInterval(proDInterval);
            proDInterval = null;
            console.log("ProD data fetching stopped.");
        }
        updateProDOverlay(null); // Clear ProD overlay values
        // ProD 오버레이 값 지우기

        // Stop event log updates for non-D reservoirs
        // D 배수지가 아닌 경우 이벤트 로그 업데이트 중지
        stopEventLogUpdates(); // 이벤트 로그 갱신 중지
        eventLogTableBody.innerHTML = '<tr><td colspan="6" class="text-center">D 배수지가 선택되면 이벤트 로그가 표시됩니다.</td></tr>';


        // Update static data charts
        // 정적 데이터 차트 업데이트
        currentInflowGraphIndex = 0;
        currentOutflowGraphIndex = 0;
        document.getElementById("inflowTitle").innerText = data.inflowData[0].label;
        document.getElementById("outflowTitle").innerText = data.outflowData[0].label;

        // Pass null to create new charts for static data
        // 정적 데이터용 새 차트를 생성하기 위해 null 전달
        updateChartWithNewData(null, 0, data.inflowData);
        updateChartWithNewData(null, 0, data.outflowData);
    }
}

// Function to fetch ProDData (communicates with Flask backend)
// ProDData 가져오기 함수 (Flask 백엔드와 통신)
async function fetchProDData(isInitial = false) {
    if (currentReservoirName !== 'D') {
        console.log("Not D reservoir, skipping ProD data fetch.");
        return;
    }

    try {
        let requestUrl = '/get_latest_pro_d_chart_data';
        if (isInitial) {
            requestUrl += '?last_time=null'; // For initial request, send 'last_time=null'
            // 초기 요청의 경우 'last_time=null' 전송
        } else if (lastKnownTimestamp) {
            requestUrl += `?last_time=${encodeURIComponent(lastKnownTimestamp)}`;
        }
        console.log(`Fetching ProD data from: ${requestUrl}`);

        const response = await fetch(requestUrl);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();

        if (data.error) {
            console.error("/get_latest_pro_d_chart_data error:", data.error);
            updateProDOverlay(null);
            return;
        }

        if (data.시각s && data.시각s.length > 0) {
            // Flask 백엔드에서 단일 최신 데이터 포인트를 반환하는 경우
            const latestIndex = 0;
            const latestDataPoint = {
                시각: data.시각s[latestIndex],
                유입유량1: data.유입유량1[latestIndex],
                유출유량1: data.유출유량1[latestIndex],
                유출유량1_예측: data.유출유량1_예측[latestIndex],
                유입유량2: data.유입유량2[latestIndex],
                유출유량2: data.유출유량2[latestIndex],
                유출유량2_예측: data.유출유량2_예측[latestIndex],
                유입개도1_추천: data.유입개도1_추천[latestIndex],
                유입개도2_추천: data.유입개도2_추천[latestIndex],
                유입개도7_추천: data.유입개도7_추천[latestIndex],
                유입개도8_추천: data.유입개도8_추천[latestIndex],
                수위1_정보: data.수위1_정보[latestIndex],
                수위2_정보: data.수위2_정보[latestIndex],
                수위7_정보: data.수위7_정보[latestIndex],
                수위8_정보: data.수위8_정보[latestIndex],
                // Event log specific data - these should also be available for the latest point
                // 이벤트 로그 특정 데이터 - 이것들도 최신 지점에서 사용 가능해야 함
                수위1_현재위험도: data.수위1_현재위험도 ? data.수위1_현재위험도[latestIndex] : null,
                수위1_예측위험도: data.수위1_예측위험도 ? data.수위1_예측위험도[latestIndex] : null,
                유입개도1_회복모드여부: data.유입개도1_회복모드여부 ? data.유입개도1_회복모드여부[latestIndex] : null,

                수위2_현재위험도: data.수위2_현재위험도 ? data.수위2_현재위험도[latestIndex] : null,
                수위2_예측위험도: data.수위2_예측위험도 ? data.수위2_예측위험도[latestIndex] : null,
                유입개도2_회복모드여부: data.유입개도2_회복모드여부 ? data.유입개도2_회복모드여부[latestIndex] : null,

                수위7_현재위험도: data.수위7_현재위험도 ? data.수위7_현재위험도[latestIndex] : null,
                수위7_예측위험도: data.수위7_예측위험도 ? data.수위7_예측위험도[latestIndex] : null,
                유입개도7_회복모드여부: data.유입개도7_회복모드여부 ? data.유입개도7_회복모드여부[latestIndex] : null,

                수위8_현재위험도: data.수위8_현재위험도 ? data.수위8_현재위험도[latestIndex] : null,
                수위8_예측위험도: data.수위8_예측위험도 ? data.수위8_예측위험도[latestIndex] : null,
                유입개도8_회복모드여부: data.유입개도8_회복모드여부 ? data.유입개도8_회복모드여부[latestIndex] : null,

                체적: data.체적[latestIndex] // ADDED: 체적 data
                // 추가됨: 체적 데이터
            };

            // --- 이 부분에서 `lastKnownTimestamp`와 현재 `latestDataPoint.시각`을 비교하여 중복 업데이트 방지 ---
            if (latestDataPoint.시각 === lastKnownTimestamp && !isInitial) {
                console.log("Same timestamp received, skipping chart and overlay update.");
                return; // 동일한 타임스탬프면 업데이트 건너뛰기
            }

            // --- UPDATE THE TIME DISPLAY HERE FOR D RESERVOIR ---
            // --- D 배수지 시간 표시 업데이트 ---
            const formattedDataTime = moment(latestDataPoint.시각).format('YYYY. MM. DD. | HH:mm:ss');
            document.getElementById('nowTime').textContent = formattedDataTime;
            // --- END TIME DISPLAY UPDATE ---
            // --- 시간 표시 업데이트 끝 ---

            // Update overview section (only for D reservoir) - only update inflow/outflow if overview type is not facility
            // 개요 섹션 업데이트 (D 배수지 전용) - 개요 유형이 시설이 아닌 경우에만 유입/유출 업데이트
            if (currentReservoirName === 'D' && reservoirStaticData.D.overview.type !== "facility") {
                document.getElementById('overview-inflow').textContent = `${latestDataPoint.유입유량1 !== null ? latestDataPoint.유입유량1.toFixed(2) : 'N/A'} m³/h`;
                document.getElementById('overview-outflow').textContent = `${latestDataPoint.유출유량1 !== null ? latestDataPoint.유출유량1.toFixed(2) : 'N/A'} m³/h`;
            }

            // Update D reservoir '수조 상태' (tank status) with '체적' data
            // '체적' 데이터를 사용하여 D 배수지 '수조 상태' 업데이트
            const volumePercentage = latestDataPoint.체적 !== null ? parseFloat(latestDataPoint.체적) : 0;
            const tankFillElement = document.getElementById('tank-level-fill-or-or-animation');
            const tankTextElement = document.getElementById('tank-info-display-text');

            tankFillElement.style.height = `${Math.min(volumePercentage, 100)}%`;
            tankTextElement.textContent = `${volumePercentage.toFixed(1)}%`;

            // Change water color based on percentage
            // 퍼센트에 따라 수조 색상 변경
            let waterColor = 'rgba(0,213,180,0.4)'; // Default: light blue-green
            // 기본값: 밝은 청록색
            if (volumePercentage < 20) {
                waterColor = 'rgba(255, 99, 132, 0.4)'; // Low: Red
                // 낮음: 빨간색
            } else if (volumePercentage < 50) {
                waterColor = 'rgba(255, 159, 64, 0.4)'; // Medium: Orange
                // 중간: 주황색
            }
            tankFillElement.querySelector('path').setAttribute('fill', waterColor);

            // Update schematic overlay values
            // 모식도 오버레이 값 업데이트
            updateProDOverlay(latestDataPoint);

            // Update D reservoir specific chart data cache
            // D 배수지 특정 차트 데이터 캐시 업데이트
            const timestamp = moment(latestDataPoint.시각).format('HH:mm:ss');
            const maxPoints = 20;

            // Update inflow1 data
            // 유입유량1 데이터 업데이트
            dReservoirChartData.inflow1.labels.push(timestamp);
            dReservoirChartData.inflow1.data.push(latestDataPoint.유입유량1);
            if (dReservoirChartData.inflow1.labels.length > maxPoints) {
                dReservoirChartData.inflow1.labels.shift();
                dReservoirChartData.inflow1.data.shift();
            }

            // Update inflow2 data
            // 유입유량2 데이터 업데이트
            dReservoirChartData.inflow2.labels.push(timestamp);
            dReservoirChartData.inflow2.data.push(latestDataPoint.유입유량2);
            if (dReservoirChartData.inflow2.labels.length > maxPoints) {
                dReservoirChartData.inflow2.labels.shift();
                dReservoirChartData.inflow2.data.shift();
            }

            // Update outflow1 data
            // 유출유량1 데이터 업데이트
            dReservoirChartData.outflow1.labels.push(timestamp);
            dReservoirChartData.outflow1.data.push(latestDataPoint.유출유량1);
            dReservoirChartData.outflow1.predData.push(latestDataPoint.유출유량1_예측 !== null && latestDataPoint.유출유량1_예측 !== undefined ? latestDataPoint.유출유량1_예측 : null);
            if (dReservoirChartData.outflow1.labels.length > maxPoints) {
                dReservoirChartData.outflow1.labels.shift();
                dReservoirChartData.outflow1.data.shift();
                dReservoirChartData.outflow1.predData.shift();
            }

            // Update outflow2 data
            // 유출유량2 데이터 업데이트
            dReservoirChartData.outflow2.labels.push(timestamp);
            dReservoirChartData.outflow2.data.push(latestDataPoint.유출유량2);
            dReservoirChartData.outflow2.predData.push(latestDataPoint.유출유량2_예측 !== null && latestDataPoint.유출유량2_예측 !== undefined ? latestDataPoint.유출유량2_예측 : null);
            if (dReservoirChartData.outflow2.labels.length > maxPoints) {
                dReservoirChartData.outflow2.labels.shift();
                dReservoirChartData.outflow2.data.shift();
                dReservoirChartData.outflow2.predData.shift();
            }

            // Update the currently displayed chart based on current index
            // 현재 인덱스에 따라 현재 표시되는 차트 업데이트
            if (currentInflowGraphIndex === 0 && inflowChartObj) {
                updateChartDisplay(inflowChartObj, dReservoirChartData.inflow1);
            } else if (currentInflowGraphIndex === 1 && inflowChartObj) {
                updateChartDisplay(inflowChartObj, dReservoirChartData.inflow2);
            }

            if (currentOutflowGraphIndex === 0 && outflowChartObj) {
                updateChartDisplay(outflowChartObj, dReservoirChartData.outflow1, true);
            } else if (currentOutflowGraphIndex === 1 && outflowChartObj) {
                updateChartDisplay(outflowChartObj, dReservoirChartData.outflow2, true);
            }

            // Update lastKnownTimestamp for the next request
            // 다음 요청을 위해 lastKnownTimestamp 업데이트
            lastKnownTimestamp = latestDataPoint.시각;
            console.log(`ProD Data updated. Last known timestamp for next fetch: ${lastKnownTimestamp}`);

            // 이벤트 로그도 여기서 최신 데이터를 사용하여 업데이트
            updateEventLogUI(latestDataPoint);

        } else {
            console.log("No new ProD data available from server for D reservoir. Waiting for next interval.");
        }
    } catch (error) {
        console.error("Failed to fetch pro_d chart data:", error);
        updateProDOverlay(null);
    }
}

// Helper to update chart display based on cached data
// 캐시된 데이터를 기반으로 차트 표시를 업데이트하는 헬퍼 함수
function updateChartDisplay(chartObj, dataCache, hasPrediction = false) {
    chartObj.data.labels = dataCache.labels;
    chartObj.data.datasets[0].data = dataCache.data;
    chartObj.data.datasets[0].label = dataCache.label;
    chartObj.data.datasets[0].borderColor = dataCache.color;
    chartObj.data.datasets[0].backgroundColor = dataCache.color + '33';

    if (hasPrediction && chartObj.data.datasets.length > 1) {
        chartObj.data.datasets[1].data = dataCache.predData;
        chartObj.data.datasets[1].label = dataCache.predLabel;
        chartObj.data.datasets[1].borderColor = dataCache.predColor;
    }
    chartObj.update();
}


// ProD Overlay update helper function
// ProD 오버레이 업데이트 헬퍼 함수
function updateProDOverlay(data) {
    console.log("Full data object received by updateProDOverlay:", data);
    // updateProDOverlay에 의해 수신된 전체 데이터 객체

    const getValue = (value) => {
        // null, undefined, 또는 NaN 값 처리
        if (value === null || value === undefined || (typeof value === 'number' && isNaN(value))) {
            return 'N/A';
        }
        // 숫자형 데이터는 소수점 두 자리로 포매팅
        if (typeof value === 'number') {
            return value.toFixed(2);
        }
        // 그 외 (문자열 등)은 그대로 반환
        return String(value);
    };

    document.getElementById('overlay-inflow2').textContent = getValue(data?.유입유량2);
    document.getElementById('overlay-outflow2').textContent = getValue(data?.유출유량2);
    document.getElementById('overlay-outflow2-pred').textContent = getValue(data?.유출유량2_예측);
    document.getElementById('overlay-gate7').textContent = getValue(data?.유입개도7_추천);
    document.getElementById('overlay-gate8').textContent = getValue(data?.유입개도8_추천);

    document.getElementById('overlay-inflow1').textContent = getValue(data?.유입유량1);
    document.getElementById('overlay-outflow1').textContent = getValue(data?.유출유량1);
    document.getElementById('overlay-outflow1-pred').textContent = getValue(data?.유출유량1_예측);
    document.getElementById('overlay-gate1-rec').textContent = getValue(data?.유입개도1_추천);
    document.getElementById('overlay-gate2-rec').textContent = getValue(data?.유입개도2_추천);

    document.getElementById('overlay-level1').textContent = getValue(data?.수위1_정보);
    document.getElementById('overlay-level2').textContent = getValue(data?.수위2_정보);
    document.getElementById('overlay-level7').textContent = getValue(data?.수위7_정보);
    document.getElementById('overlay-level8').textContent = getValue(data?.수위8_정보);
}

// Event Log Specific JavaScript (Integrated)
// 이벤트 로그 특정 JavaScript (통합)
const eventLogTableBody = document.getElementById('eventLogTableBody');
const MAX_LOG_ROWS = 10; // 테이블에 표시할 최대 로그 행 수

// 위험도에 따른 색상 정의
const riskColors = {
    "정상": "#28a745", // 진한 녹색 (Bootstrap 'success' green)
    "주의": "#ffc107", // 주황빛 노란색 (Bootstrap 'warning' yellow)
    "경고": "#fd7e14", // 오렌지색 (Bootstrap 'orange')
    "위험": "#dc3545"  // 진한 빨강 (Bootstrap 'danger' red)
};

// 위험도 중요도 순서 (인덱스가 낮을수록 중요도가 낮음)
const riskLevels = ["정상", "주의", "경고", "위험"];

// 위험도 문자열을 인덱스로 변환하는 헬퍼 함수
function getRiskLevelIndex(status) {
    return riskLevels.indexOf(status);
}

// 현재 상태와 예상 위험도 중 더 높은 위험도에 해당하는 색상 결정
function determineRowColor(currentStatus, predictedStatus) {
    const currentLevelIndex = getRiskLevelIndex(currentStatus);
    const predictedLevelIndex = getRiskLevelIndex(predictedStatus);

    // 둘 중 더 높은 위험도(더 큰 인덱스)를 선택
    const highestRiskIndex = Math.max(currentLevelIndex, predictedLevelIndex);
    const highestRiskStatus = riskLevels[highestRiskIndex];

    return riskColors[highestRiskStatus] || "transparent"; // 기본값은 투명
}

let eventLogInterval; // setInterval ID를 저장할 변수
let lastEventLogTimestamp = null; // 이벤트 로그의 마지막 갱신 시각

// 이벤트 로그 UI를 갱신하는 함수 (fetchDReservoirData 대신 fetchProDData에서 받아온 latestDataPoint 사용)
function updateEventLogUI(latestDataPoint) {
    if (!latestDataPoint || !latestDataPoint.시각) {
        console.warn("이벤트 로그를 위한 데이터가 없거나 유효하지 않습니다.");
        return;
    }

    // 동일한 타임스탬프인 경우 업데이트 건너뛰기
    if (latestDataPoint.시각 === lastEventLogTimestamp) {
        console.log("Event log: Same timestamp received, skipping UI update.");
        return;
    }

    const tanks = [1, 2, 7, 8];
    const newLogs = [];

    tanks.forEach(tankIndex => {
        const timestamp = latestDataPoint.시각 ? moment(latestDataPoint.시각).format('YYYY-MM-DD HH:mm:ss') : moment().format('YYYY-MM-DD HH:mm:ss');
        const tankName = `수조 ${tankIndex}`;

        // 데이터 존재 여부 확인 및 포매팅 헬퍼 함수들
        const formatValue = (val, isPercentage = false) => {
            if (val === null || val === undefined) return 'N/A';
            if (isPercentage && typeof val === 'number') {
                return `${val.toFixed(1)}%`;
            }
            return String(val); // 문자열 그대로 반환 (JSON.parse 불필요)
        };

        const currentStatus = formatValue(latestDataPoint[`수위${tankIndex}_현재위험도`]);
        const predictedStatus = formatValue(latestDataPoint[`수위${tankIndex}_예측위험도`]);
        const recoveryMode = formatValue(latestDataPoint[`유입개도${tankIndex}_회복모드여부`]) === 'Y' ? 'ON' : 'OFF';
        const aiRecommendation = formatValue(latestDataPoint[`유입개도${tankIndex}_추천`], true);

        const rowColor = determineRowColor(currentStatus, predictedStatus);

        newLogs.push({
            timestamp,
            tankName,
            currentStatus,
            predictedStatus,
            recoveryMode,
            aiRecommendation,
            rowColor
        });
    });

    // Add new logs to the table, ensuring the newest are at the top
    // 기존 로그를 지우고 새로운 데이터로 채우는 대신, 새 데이터가 있을 때만 추가
    newLogs.reverse().forEach(log => {
        const newRow = eventLogTableBody.insertRow(0); // 맨 위에 삽입
        newRow.style.backgroundColor = log.rowColor;
        newRow.style.color = 'black';

        newRow.insertCell(0).textContent = log.timestamp.substring(11,19); // 시간만 표시 (HH:MM:SS)
        newRow.insertCell(1).textContent = log.tankName;
        newRow.insertCell(2).textContent = log.currentStatus;
        newRow.insertCell(3).textContent = log.predictedStatus;
        newRow.insertCell(4).textContent = log.recoveryMode;
        newRow.insertCell(5).textContent = log.aiRecommendation;
    });

    // 최대 행 개수 유지
    while (eventLogTableBody.rows.length > MAX_LOG_ROWS) {
        eventLogTableBody.deleteRow(eventLogTableBody.rows.length - 1); // 가장 오래된 행 제거
    }

    // 마지막 갱신 타임스탬프 업데이트
    lastEventLogTimestamp = latestDataPoint.시각;
}


// 이벤트 로그 갱신 시작 (이전 fetchDReservoirData 대신 updateEventLogUI 호출)
function startEventLogUpdates() {
    // 이미 실행 중이라면 중지 후 재시작
    if (eventLogInterval) {
        clearInterval(eventLogInterval);
    }
    // updateEventLogUI는 fetchProDData 내부에서 호출되므로 여기서 별도로 setInterval을 걸지 않음
    // fetchProDData가 10초마다 실행되므로, 그 안에서 updateEventLogUI가 함께 호출되도록 함
    console.log("이벤트 로그 갱신은 ProD 데이터 갱신과 함께 처리됩니다.");
}

// 이벤트 로그 갱신 중지
function stopEventLogUpdates() {
    // eventLogInterval은 더 이상 사용되지 않음
    // 대신 ProDInterval이 중지되면 이벤트 로그 갱신도 함께 중지됨
    console.log("이벤트 로그 갱신 중지됨 (ProD 데이터 갱신 중지에 따름).");
}

// DOMContentLoaded event listener
// DOMContentLoaded 이벤트 리스너
document.addEventListener('DOMContentLoaded', () => {
    const currentPath = window.location.pathname;

    // Activate sidebar link based on current path
    // 현재 경로에 따라 사이드바 링크 활성화
    document.querySelectorAll('.sidebar a').forEach(link => {
        const linkHref = link.getAttribute('href');
        if (linkHref === currentPath || (linkHref === '{{ url_for("index") }}' && currentPath === '/')) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });

    // Apply AI autonomous operation mode on page load
    // 페이지 로드 시 AI 자율 운영 모드 적용
    applyMode();

    // Initial reservoir load (A reservoir)
    // 초기 배수지 로드 (A 배수지)
    updateReservoir('A'); // This will now correctly set up the time display
    // 이제 시간이 올바르게 설정됩니다.
    document.querySelector('.reservoir-btn[data-name="A"]').classList.add('active');

    // Reservoir button click events
    // 배수지 버튼 클릭 이벤트
    document.querySelectorAll('.reservoir-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.reservoir-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            updateReservoir(btn.dataset.name);
        });
    });
});