const ctx = document.getElementById("chart").getContext("2d");
const CHART_COLORS = {
    blue: 'rgb(54, 162, 235)',
    red: 'rgb(255, 99, 132)',
    green: 'rgb(75, 192, 192)',
    purple: 'rgb(153, 102, 255)',
    orange: 'rgb(255, 159, 64)',
    teal: 'rgb(0, 128, 128)',
    lime: 'rgb(50, 205, 50)',
    pink: 'rgb(255, 192, 203)',
    brown: 'rgb(165, 42, 42)'
};

let currentInterval = null;
let lastTimestamp = null; 
let selectedReservoir = 'C';
let currentChartType = '유량';
let previousAverageWaterLevel = null; // 이전 평균 수위 저장

// D 배수지의 실시간 데이터를 저장할 전역 변수 (모든 차트 유형이 공유)
let dReservoirRealtimeData = {
    labels: [],
    inflow: [], // 총 유입유량
    outflow: [], // 총 유출유량
    level1: [],
    level2: [],
    level7: [],
    level8: [],
    openRate1: [],
    openRate2: [],
    openRate7: [],
    openRate8: []
};

const MAX_DATA_POINTS = 30; // 약 5분치 데이터 (10초마다 갱신 시)

// Chart.js 플러그인: Y축 배경색 그리기
const yAxisBackgroundPlugin = {
    id: 'yAxisBackground',
    beforeDraw: (chart) => {
        // 'D' 배수지 선택 및 '수위' 차트일 때만 플러그인 활성화
        if (chart.options.plugins.yAxisBackground && chart.options.plugins.yAxisBackground.enabled && selectedReservoir === 'D' && currentChartType === '수위') {
            const { ctx, chartArea, scales } = chart;
            const y = scales.y;

            const ranges = [
                { start: 95, end: y.max, color: 'rgba(255, 99, 132, 0.2)' }, // 95 이상 - 붉은색 계열
                { start: 91, end: 95, color: 'rgba(255, 206, 86, 0.2)' }, // 91 이상 95 미만 - 노란색 계열
                { start: 80, end: 91, color: 'rgba(75, 192, 192, 0.2)' }, // 80 이상 91 미만 - 초록색 계열
                { start: 65, end: 80, color: 'rgba(255, 206, 86, 0.2)' }, // 65 이상 80 미만 - 노란색 계열
                { start: y.min, end: 65, color: 'rgba(255, 99, 132, 0.2)' } // 65 미만 - 붉은색 계열
            ];

            ctx.save();
            ctx.beginPath();
            ctx.rect(chartArea.left, chartArea.top, chartArea.right - chartArea.left, chartArea.bottom - chartArea.top);
            ctx.clip();

            ranges.forEach(range => {
                const yStart = y.getPixelForValue(Math.min(Math.max(range.start, y.min), y.max)); // Y축 범위 내에서 값 조정
                const yEnd = y.getPixelForValue(Math.min(Math.max(range.end, y.min), y.max));
                
                const top = Math.min(yStart, yEnd);
                const bottom = Math.max(yStart, yEnd);
                const height = bottom - top;

                ctx.fillStyle = range.color;
                ctx.fillRect(chartArea.left, top, chartArea.right - chartArea.left, height);
            });
            ctx.restore();
        }
    }
};
Chart.register(yAxisBackgroundPlugin);

const chart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [],
        datasets: []
    },
    options: {
        maintainAspectRatio: false,
        responsive: true,
        plugins: {
            legend: {
                display: true,
                labels: {
                    color: "#9e9e9e"
                }
            },
            yAxisBackground: {
                enabled: false
            }
        },
        scales: {
            y: {
                beginAtZero: false,
                ticks: {
                    color: "#9e9e9e",
                    callback: function(value, index, ticks) { // Y축 단위 추가
                        let unit = "";
                        if (currentChartType === '유량') {
                            unit = "㎥/5분";
                        } else if (currentChartType === '수위' || currentChartType === '개도율') {
                            unit = "%";
                        }
                        return value + unit;
                    }
                },
                grid: { color: 'rgba(29,140,248,0.1)' },
            },
            x: {
                ticks: {
                    color: "#9e9e9e",
                    maxTicksLimit: 8,
                    callback: function(value, index, ticks) {
                        const label = this.getLabelForValue(value);
                        const time = new Date(label);
                        if (!isNaN(time.getTime())) {
                            // 여기에서 시간 포맷을 변경할 수 있습니다.
                            return time.toLocaleTimeString('ko-KR', {
                                hour: '2-digit',
                                minute: '2-digit',
                                second: '2-digit'
                            });
                        }
                        return label;
                    }
                },
                grid: { color: 'rgba(220,220,220,0.1)' }
            }
        },
        animation: {
            duration: 0
        }
    }
});

// D 배수지의 실시간 데이터를 가져와 dReservoirRealtimeData에 저장
async function fetchDReservoirData() {
    const url = `/get_latest_pro_d_chart_data?last_time=${lastTimestamp || 'null'}`;
    console.log(`D 배수지 데이터 가져오는 중: ${url}`);
    
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP 오류! 상태: ${response.status}`);
        }
        const data = await response.json();
        console.log("수신 데이터 (D 배수지):", data);

        if (data && data.labels && data.labels.length > 0) {
            const newTimestamp = data.labels[0];
            const lastStoredLabel = dReservoirRealtimeData.labels[dReservoirRealtimeData.labels.length - 1];

            // 새로운 데이터의 타임스탬프가 이미 저장된 마지막 라벨보다 같거나 이전이면 중복으로 간주하고 건너뜀
            if (lastStoredLabel && new Date(newTimestamp).getTime() <= new Date(lastStoredLabel).getTime()) {
                console.log("새로운 데이터가 없거나 중복된 타임스탬프입니다. 업데이트를 건너뜠습니다.");
                updateCurrentDataTime(lastStoredLabel); // 데이터가 갱신되지 않아도 마지막으로 표시된 시간을 유지
                return;
            }

            // lastTimestamp 업데이트 (다음 요청을 위해)
            lastTimestamp = newTimestamp;

            // 데이터 포인트가 MAX_DATA_POINTS를 초과하면 가장 오래된 데이터 제거
            if (dReservoirRealtimeData.labels.length >= MAX_DATA_POINTS) {
                for (const key in dReservoirRealtimeData) {
                    if (Array.isArray(dReservoirRealtimeData[key])) {
                        dReservoirRealtimeData[key].shift();
                    }
                }
            }
            
            // 새 데이터 추가
            dReservoirRealtimeData.labels.push(newTimestamp);
            dReservoirRealtimeData.inflow.push(((data.유입유량1 && typeof data.유입유량1[0] !== 'undefined') ? parseFloat(data.유입유량1[0]) : 0) + ((data.유입유량2 && typeof data.유입유량2[0] !== 'undefined') ? parseFloat(data.유입유량2[0]) : 0));
            dReservoirRealtimeData.outflow.push(((data.유출유량1 && typeof data.유출유량1[0] !== 'undefined') ? parseFloat(data.유출유량1[0]) : 0) + ((data.유출유량2 && typeof data.유출유량2[0] !== 'undefined') ? parseFloat(data.유출유량2[0]) : 0));
            dReservoirRealtimeData.level1.push((data.수위1_예측 && typeof data.수위1_예측[0] !== 'undefined') ? parseFloat(data.수위1_예측[0]) : 0);
            dReservoirRealtimeData.level2.push((data.수위2_예측 && typeof data.수위2_예측[0] !== 'undefined') ? parseFloat(data.수위2_예측[0]) : 0);
            dReservoirRealtimeData.level7.push((data.수위7_예측 && typeof data.수위7_예측[0] !== 'undefined') ? parseFloat(data.수위7_예측[0]) : 0);
            dReservoirRealtimeData.level8.push((data.수위8_예측 && typeof data.수위8_예측[0] !== 'undefined') ? parseFloat(data.수위8_예측[0]) : 0);
            dReservoirRealtimeData.openRate1.push((data.유입개도1_추천 && typeof data.유입개도1_추천[0] !== 'undefined') ? parseFloat(data.유입개도1_추천[0]) : 0);
            dReservoirRealtimeData.openRate2.push((data.유입개도2_추천 && typeof data.유입개도2_추천[0] !== 'undefined') ? parseFloat(data.유입개도2_추천[0]) : 0);
            dReservoirRealtimeData.openRate7.push((data.유입개도7_추천 && typeof data.유입개도7_추천[0] !== 'undefined') ? parseFloat(data.유입개도7_추천[0]) : 0);
            dReservoirRealtimeData.openRate8.push((data.유입개도8_추천 && typeof data.유입개도8_추천[0] !== 'undefined') ? parseFloat(data.유입개도8_추천[0]) : 0);

            // 데이터가 업데이트될 때마다 현재 활성화된 차트 유형에 맞춰 차트 데이터 업데이트
            updateChartData(currentChartType);
            
            // D 배수지 상태 및 변화율 업데이트 (가장 최신 데이터 기준)
            const latestWaterLevels = [
                dReservoirRealtimeData.level1[dReservoirRealtimeData.level1.length - 1],
                dReservoirRealtimeData.level2[dReservoirRealtimeData.level2.length - 1],
                dReservoirRealtimeData.level7[dReservoirRealtimeData.level7.length - 1],
                dReservoirRealtimeData.level8[dReservoirRealtimeData.level8.length - 1]
            ];
            updateDReservoirStatus(latestWaterLevels);

            // 여기에서 '현재시간'을 업데이트합니다.
            updateCurrentDataTime(newTimestamp);

        } else {
            console.warn("새로운 데이터가 수신되지 않았거나 데이터가 비어 있습니다.");
            // 데이터가 없거나 빈 배열일 때도 마지막으로 업데이트된 시간으로 표시를 유지
            if (dReservoirRealtimeData.labels.length > 0) {
                 updateCurrentDataTime(dReservoirRealtimeData.labels[dReservoirRealtimeData.labels.length - 1]);
            } else {
                // 아직 아무 데이터도 없는 경우 기본값으로 표시 (예: "데이터 로딩 중...")
                document.getElementById('currentDataTime').textContent = "데이터 로딩 중...";
            }
        }
    } catch (error) {
        console.error("실시간 차트 데이터 가져오기 실패:", error);
        document.getElementById('currentDataTime').textContent = "데이터 로딩 오류!";
    }
}

// D 배수지 상태 (경고, 수위 변화율) 업데이트 함수
function updateDReservoirStatus(waterLevels) {
    const dCard = document.getElementById('d-reservoir-card');
    const dStatus = document.getElementById('d-reservoir-status');
    const dRate = document.getElementById('d-reservoir-rate');

    let isAlert = false;
    // 예측 수위가 95 이상이거나 65 미만일 때 위험 경고
    for (const level of waterLevels) {
        if (level > 95 || level < 65) {
            isAlert = true;
            break;
        }
    }

    if (isAlert) {
        dCard.classList.add('alert');
        dStatus.textContent = '이상치 경고!';
        dRate.classList.remove('rate-positive', 'rate-negative');
        dRate.classList.add('rate-alert');
    } else {
        dCard.classList.remove('alert');
        dStatus.textContent = '정상 운영 중';
        dRate.classList.remove('rate-alert');
        dRate.classList.add('rate-positive'); // 기본적으로 rate-positive 유지 (음수면 변경)
    }

    const currentAverageWaterLevel = waterLevels.reduce((sum, val) => sum + val, 0) / waterLevels.length;
    
    let changeRate = 0;
    // 데이터 포인트가 2개 이상일 때만 변화율 계산 (최소 두 시점 필요)
    if (dReservoirRealtimeData.labels.length > 1 && previousAverageWaterLevel !== null && previousAverageWaterLevel !== 0) {
        changeRate = ((currentAverageWaterLevel - previousAverageWaterLevel) / previousAverageWaterLevel) * 100;
    } else if (dReservoirRealtimeData.labels.length <= 1) {
        // 첫 데이터일 경우 변화율 0%로 설정
        changeRate = 0;
    }

    dRate.textContent = `${changeRate.toFixed(1)}%`;
    if (changeRate > 0) {
        dRate.classList.add('rate-positive');
        dRate.classList.remove('rate-negative');
    } else if (changeRate < 0) {
        dRate.classList.add('rate-negative');
        dRate.classList.remove('rate-positive');
    } else {
        dRate.classList.remove('rate-positive', 'rate-negative');
    }
    
    previousAverageWaterLevel = currentAverageWaterLevel;
}


// 차트 데이터셋만 업데이트하는 함수
function updateChartData(type) {
    chart.data.labels = [...dReservoirRealtimeData.labels]; // 라벨은 D 배수지 데이터에서 가져옴
    chart.data.datasets = []; // 데이터셋 초기화

    if (type === '유량') {
        chart.options.scales.y.beginAtZero = true;
        chart.options.scales.y.min = undefined;
        chart.options.scales.y.max = undefined;
        chart.data.datasets.push({
            label: '총 유입유량',
            borderColor: CHART_COLORS.blue,
            backgroundColor: function(context) {
                const chart = context.chart;
                const { ctx, chartArea } = chart;
                if (!chartArea) return CHART_COLORS.blue.replace('rgb', 'rgba').replace(')', ',0.2)');
                const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
                gradient.addColorStop(1, CHART_COLORS.blue.replace('rgb', 'rgba').replace(')', ',0.2)'));
                gradient.addColorStop(0.4, CHART_COLORS.blue.replace('rgb', 'rgba').replace(')', ',0.0)'));
                gradient.addColorStop(0, CHART_COLORS.blue.replace('rgb', 'rgba').replace(')', ',0)'));
                return gradient;
            },
            borderWidth: 2,
            pointBackgroundColor: CHART_COLORS.blue,
            data: [...dReservoirRealtimeData.inflow],
            fill: true,
            tension: 0.4
        });
        chart.data.datasets.push({
            label: '총 유출유량',
            borderColor: CHART_COLORS.red,
            backgroundColor: function(context) {
                const chart = context.chart;
                const { ctx, chartArea } = chart;
                if (!chartArea) return CHART_COLORS.red.replace('rgb', 'rgba').replace(')', ',0.2)');
                const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
                gradient.addColorStop(1, CHART_COLORS.red.replace('rgb', 'rgba').replace(')', ',0.2)'));
                gradient.addColorStop(0.4, CHART_COLORS.red.replace('rgb', 'rgba').replace(')', ',0.0)'));
                gradient.addColorStop(0, CHART_COLORS.red.replace('rgb', 'rgba').replace(')', ',0)'));
                return gradient;
            },
            borderWidth: 2,
            pointBackgroundColor: CHART_COLORS.red,
            data: [...dReservoirRealtimeData.outflow],
            fill: true,
            tension: 0.4
        });
    } else if (type === '수위') {
        chart.options.scales.y.beginAtZero = false;
        chart.options.scales.y.min = 60; 
        chart.options.scales.y.max = 100;

        chart.data.datasets.push({
            label: '수위1',
            borderColor: CHART_COLORS.green,
            backgroundColor: CHART_COLORS.green.replace('rgb', 'rgba').replace(')', ',0.1)'),
            borderWidth: 2,
            pointBackgroundColor: CHART_COLORS.green,
            data: [...dReservoirRealtimeData.level1],
            fill: false,
            tension: 0.4
        });
        chart.data.datasets.push({
            label: '수위2',
            borderColor: CHART_COLORS.purple,
            backgroundColor: CHART_COLORS.purple.replace('rgb', 'rgba').replace(')', ',0.1)'),
            borderWidth: 2,
            pointBackgroundColor: CHART_COLORS.purple,
            data: [...dReservoirRealtimeData.level2],
            fill: false,
            tension: 0.4
        });
        chart.data.datasets.push({
            label: '수위7',
            borderColor: CHART_COLORS.orange,
            backgroundColor: CHART_COLORS.orange.replace('rgb', 'rgba').replace(')', ',0.1)'),
            borderWidth: 2,
            pointBackgroundColor: CHART_COLORS.orange,
            data: [...dReservoirRealtimeData.level7],
            fill: false,
            tension: 0.4
        });
        chart.data.datasets.push({
            label: '수위8',
            borderColor: CHART_COLORS.teal,
            backgroundColor: CHART_COLORS.teal.replace('rgb', 'rgba').replace(')', ',0.1)'),
            borderWidth: 2,
            pointBackgroundColor: CHART_COLORS.teal,
            data: [...dReservoirRealtimeData.level8],
            fill: false,
            tension: 0.4
        });

    } else if (type === '개도율') {
        chart.options.scales.y.beginAtZero = true;
        chart.options.scales.y.min = 0;
        chart.options.scales.y.max = 100;
        chart.data.datasets.push({
            label: '유입개도1',
            borderColor: CHART_COLORS.blue,
            backgroundColor: CHART_COLORS.blue.replace('rgb', 'rgba').replace(')', ',0.2)'),
            borderWidth: 2,
            pointBackgroundColor: CHART_COLORS.blue,
            data: [...dReservoirRealtimeData.openRate1],
            fill: false,
            tension: 0.4
        });
        chart.data.datasets.push({
            label: '유입개도2',
            borderColor: CHART_COLORS.green,
            backgroundColor: CHART_COLORS.green.replace('rgb', 'rgba').replace(')', ',0.2)'),
            borderWidth: 2,
            pointBackgroundColor: CHART_COLORS.green,
            data: [...dReservoirRealtimeData.openRate2],
            fill: false,
            tension: 0.4
        });
        chart.data.datasets.push({
            label: '유입개도7',
            borderColor: CHART_COLORS.purple,
            backgroundColor: CHART_COLORS.purple.replace('rgb', 'rgba').replace(')', ',0.2)'),
            borderWidth: 2,
            pointBackgroundColor: CHART_COLORS.purple,
            data: [...dReservoirRealtimeData.openRate7],
            fill: false,
            tension: 0.4
        });
        chart.data.datasets.push({
            label: '유입개도8',
            borderColor: CHART_COLORS.orange,
            backgroundColor: CHART_COLORS.orange.replace('rgb', 'rgba').replace(')', ',0.2)'),
            borderWidth: 2,
            pointBackgroundColor: CHART_COLORS.orange,
            data: [...dReservoirRealtimeData.openRate8],
            fill: false,
            tension: 0.4
        });
    }
    
    chart.update();
}


// 차트 유형 변경 버튼 클릭 시 호출되는 메인 함수 (이전 updateChart 이름 변경)
function setChartType(type, el) {
    const buttons = document.querySelectorAll('.chart-card-button');
    buttons.forEach(btn => btn.classList.remove('active'));
    if (el) el.classList.add('active');

    currentChartType = type;

    // Y축 배경 플러그인 활성화/비활성화 설정
    chart.options.plugins.yAxisBackground.enabled = (selectedReservoir === 'D' && type === '수위');

    if (selectedReservoir === 'D') {
        // D 배수지인 경우, 기존에 저장된 실시간 데이터를 바탕으로 차트만 업데이트
        updateChartData(type);
    } else {
        // D 배수지가 아닐 경우, 기본 데이터 로드
        chart.options.scales.y.beginAtZero = true; // 기본 데이터는 0부터 시작하도록 설정
        chart.options.scales.y.min = undefined;
        chart.options.scales.y.max = undefined;
        
        chart.data.labels = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월']; // 기본 데이터는 라벨도 다시 설정
        chart.data.datasets = []; // 기본 데이터는 데이터셋도 다시 설정

        if (type === '유량') {
            chart.data.datasets.push({
                label: '유량 (기본 데이터)',
                borderColor: "#1f8ef1",
                backgroundColor: function(context) {
                    const chart = context.chart;
                    const { ctx, chartArea } = chart;
                    if (!chartArea) return 'rgba(29,140,248,0.2)';
                    const gradient = ctx.createLinearGradient(0, chartArea.bottom, 0, chartArea.top);
                    gradient.addColorStop(1, 'rgba(29,140,248,0.2)');
                    gradient.addColorStop(0.4, 'rgba(29,140,248,0.0)');
                    gradient.addColorStop(0, 'rgba(29,140,248,0)');
                    return gradient;
                },
                borderWidth: 2,
                data: [23000, 24000, 27000, 32000, 38000, 35000, 30000, 28000],
                fill: true,
                tension: 0.4
            });
        } else if (type === '수위') {
            chart.options.scales.y.beginAtZero = false; // 기본 수위 데이터도 특정 범위
            chart.options.scales.y.min = 60;
            chart.options.scales.y.max = 100;
            chart.data.datasets = [
                {
                    label: '수위1 (기본 데이터)', borderColor: CHART_COLORS.green,
                    backgroundColor: CHART_COLORS.green.replace('rgb', 'rgba').replace(')', ',0.1)'),
                    borderWidth: 2, pointBackgroundColor: CHART_COLORS.green, data: [85, 87, 88, 90, 89, 86, 85, 84], fill: false, tension: 0.4
                },
                {
                    label: '수위2 (기본 데이터)', borderColor: CHART_COLORS.purple,
                    backgroundColor: CHART_COLORS.purple.replace('rgb', 'rgba').replace(')', ',0.1)'),
                    borderWidth: 2, pointBackgroundColor: CHART_COLORS.purple, data: [80, 82, 83, 85, 84, 81, 80, 79], fill: false, tension: 0.4
                },
                {
                    label: '수위7 (기본 데이터)', borderColor: CHART_COLORS.orange,
                    backgroundColor: CHART_COLORS.orange.replace('rgb', 'rgba').replace(')', ',0.1)'),
                    borderWidth: 2, pointBackgroundColor: CHART_COLORS.orange, data: [90, 92, 93, 95, 94, 91, 90, 89], fill: false, tension: 0.4
                },
                {
                    label: '수위8 (기본 데이터)', borderColor: CHART_COLORS.teal,
                    backgroundColor: CHART_COLORS.teal.replace('rgb', 'rgba').replace(')', ',0.1)'),
                    borderWidth: 2, pointBackgroundColor: CHART_COLORS.teal, data: [75, 77, 78, 80, 79, 76, 75, 74], fill: false, tension: 0.4
                }
            ];
        } else if (type === '개도율') {
            chart.options.scales.y.beginAtZero = true;
            chart.options.scales.y.min = 0;
            chart.options.scales.y.max = 100;
            chart.data.datasets = [
                {
                    label: '유입개도1 (기본 데이터)', borderColor: CHART_COLORS.blue,
                    backgroundColor: CHART_COLORS.blue.replace('rgb', 'rgba').replace(')', ',0.2)'),
                    borderWidth: 2, pointBackgroundColor: CHART_COLORS.blue, data: [50, 55, 60, 65, 70, 60, 55, 50], fill: false, tension: 0.4
                },
                {
                    label: '유입개도2 (기본 데이터)', borderColor: CHART_COLORS.green,
                    backgroundColor: CHART_COLORS.green.replace('rgb', 'rgba').replace(')', ',0.2)'),
                    borderWidth: 2, pointBackgroundColor: CHART_COLORS.green, data: [45, 50, 55, 60, 65, 55, 50, 45], fill: false, tension: 0.4
                },
                {
                    label: '유입개도7 (기본 데이터)', borderColor: CHART_COLORS.purple,
                    backgroundColor: CHART_COLORS.purple.replace('rgb', 'rgba').replace(')', ',0.2)'),
                    borderWidth: 2, pointBackgroundColor: CHART_COLORS.purple, data: [60, 65, 70, 75, 80, 70, 65, 60], fill: false, tension: 0.4
                },
                {
                    label: '유입개도8 (기본 데이터)', borderColor: CHART_COLORS.orange,
                    backgroundColor: CHART_COLORS.orange.replace('rgb', 'rgba').replace(')', ',0.2)'),
                    borderWidth: 2, pointBackgroundColor: CHART_COLORS.orange, data: [40, 45, 50, 55, 60, 50, 45, 40], fill: false, tension: 0.4
                }
            ];
        }
        chart.update();
    }
}


function selectReservoir(region) {
    document.getElementById("region-title").textContent = `${region} 배수지`;
    document.getElementById("map-image").src = `/static/images/${region}지도.png`;
    
    // 이전에 선택된 배수지와 현재 선택된 배수지가 다를 때만 lastTimestamp 초기화
    if (selectedReservoir !== region) {
        lastTimestamp = null; // 배수지 변경 시 lastTimestamp 초기화하여 새 배수지 데이터 처음부터 로드
        // 다른 배수지에서 D 배수지로 넘어올 때 dReservoirRealtimeData 초기화 (새로운 실시간 스트림)
        // D 배수지가 아니었다가 D 배수지를 선택할 때만 dReservoirRealtimeData를 초기화합니다.
        if (region === 'D') {
            dReservoirRealtimeData = {
                labels: [], inflow: [], outflow: [], level1: [], level2: [], level7: [], level8: [],
                openRate1: [], openRate2: [], openRate7: [], openRate8: []
            };
            previousAverageWaterLevel = null; // 평균 수위 변화율 계산을 위한 초기화
        } else {
            // D 배수지가 아니면 currentDataTime을 초기화 (데이터가 없는 상태)
            document.getElementById('currentDataTime').textContent = "---";
        }
    }
    selectedReservoir = region; 
    
    // 기존 인터벌이 있다면 중지
    if (currentInterval) {
        clearInterval(currentInterval);
        currentInterval = null;
    }

    if (region === 'D') {
        // D 배수지 선택 시 카드 상태 초기화
        const dCard = document.getElementById('d-reservoir-card');
        const dStatus = document.getElementById('d-reservoir-status');
        const dRate = document.getElementById('d-reservoir-rate');
        dCard.classList.remove('alert');
        dStatus.textContent = '정상 운영 중';
        dRate.classList.remove('rate-alert', 'rate-negative');
        dRate.classList.add('rate-positive');
        dRate.textContent = `0.0%`; // Reset rate initially

        // 'D' 배수지 선택 시 실시간 데이터 가져오기 시작
        fetchDReservoirData(); // 즉시 데이터 로드
        currentInterval = setInterval(fetchDReservoirData, 10000); // 10초마다 업데이트
    } 
    
    // 차트 유형 버튼의 활성화 상태를 유지하고 해당 유형의 차트를 표시 (D든 아니든)
    const activeButton = document.querySelector('.chart-card-button.active');
    const initialChartType = activeButton ? activeButton.textContent : '유량'; 
    setChartType(initialChartType, activeButton); // 이름을 변경한 함수 호출
}

function highlightRegion(region) {
    document.getElementById("map-image").src = `/static/images/${region}지도.png`;
}

function resetMap() {
    // 선택된 배수지가 'D'가 아닐 때만 기본 지도로 돌아갑니다.
    if (selectedReservoir !== 'D') {
        document.getElementById("map-image").src = "/static/images/기본지도.png";
    }
}

// ---------------------------------------------------------------
// 기존 updateTime 함수를 제거하고, 데이터의 최신 시각을 표시하는 함수로 대체합니다.
function updateCurrentDataTime(timestampString) {
    if (timestampString) {
        try {
            // ISO 8601 문자열을 Date 객체로 파싱
            const date = new Date(timestampString);
            // 원하는 형식으로 포맷: YYYY. MM. DD | HH:MM:SS
            const dateStr = `${date.getFullYear()}. ${String(date.getMonth() + 1).padStart(2, '0')}. ${String(date.getDate()).padStart(2, '0')} | ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:${String(date.getSeconds()).padStart(2, '0')}`;
            document.getElementById('currentDataTime').textContent = dateStr;
        } catch (e) {
            console.error("날짜 파싱 오류:", e, timestampString);
            document.getElementById('currentDataTime').textContent = "시간 형식 오류";
        }
    } else {
        document.getElementById('currentDataTime').textContent = "데이터 로딩 중...";
    }
}

// 기존 setInterval(updateTime, 1000); 호출과 updateTime() 초기 호출을 제거합니다.
// ---------------------------------------------------------------


document.addEventListener('DOMContentLoaded', () => {
    // 초기 로드 시 'C' 배수지 선택 및 '유량' 차트 활성화
    selectReservoir('C'); 
    // 초기 로드 시 '유량' 버튼을 활성화된 상태로 설정
    const initialActiveButton = document.querySelector('.chart-card-button'); // 첫 번째 버튼
    if (initialActiveButton) {
        initialActiveButton.classList.add('active');
        setChartType('유량', initialActiveButton); // 이름 변경된 함수 호출
    }
    // 초기 로드 시 현재시간 초기값 설정 (데이터 로딩 전)
    document.getElementById('currentDataTime').textContent = "데이터 로딩 중...";
});