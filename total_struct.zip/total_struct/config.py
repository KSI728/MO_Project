# config.py

class Config: 
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://ksi:1234@localhost:3306/mindone'

    # SQLAlchemy 이벤트 추적을 비활성화 : 불필요한 메모리 사용을 줄이고 성능을 향상
    SQLALCHEMY_TRACK_MODIFICATIONS = False